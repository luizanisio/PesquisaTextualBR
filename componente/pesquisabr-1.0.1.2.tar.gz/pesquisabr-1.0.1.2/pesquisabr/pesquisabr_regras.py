# -*- coding: utf-8 -*-
#######################################################################
# Esse código, dicas de uso e outras informações: 
#   -> https://github.com/luizanisio/PesquisaTextualBR
# Luiz Anísio 
# 30/11/2020 - disponibilizado no GitHub  
#######################################################################

from copy import deepcopy
import re
from datetime import datetime

from pesquisabr import PesquisaBR
from pesquisabr.pesquisabr_extracao import UtilExtracaoRe


class RegrasPesquisaBR():
  ''' O retorno contém:
       - retorno = True/False se os critérios foram atendidos no texto analisado
       - erros = mensagem de erro quando os critérios são mal formados
       - tempo = tempo em segundos para o processamento
       (grifar = True)
       - texto_grifado = texto original grifado com os critérios analisados (não disponível nas regras)
       (extrair = True)
       - extracoes = disponível apenas nas regras de regex/like
       (detalhar = True)
       - texto_analise = texto original recebido para avaliação das regras ou critérios
       - texto = texto processado pelo tido de avaliação feita (regex/like/PesquisaBR), em regras é o texto para PesquisaBR
       - texto_regex = no caso de regras, texto processado usado no regex 
       - criterios_analise = critérios originais recebidos para análise
       - criterios = critérios processados pelo tipo de avaliação feita
       - criterios_aon = critérios convertidos para AND/OR/NOT no caso de PesquisaBR
  '''

  def __init__(self, regras = [], print_debug = False):
      self.print_debug = print_debug
      # é necessário unir as regras de cada grupo e, se existir, ordena pela ordem no grupo
      self.regras = self.ordenar_regras(regras)
      # [print(_) for _ in self.regras]

  @classmethod
  def ordenar_regras(self, regras):
      return sorted(regras, key=lambda k:(k.get('grupo',''), k.get('ordem',0)))

  # retorna o critério like, regex ou None se não for nenhum dos dois 
  # e: regex de extração
  # l: like para ser convertido para regex
  # r: regex
  @classmethod
  def regra_like_regex(self, criterios):
      regra_like = None
      regra_regex = None
      if criterios[:2] in {'r:','R:'}:
         regra_regex = criterios[2:]
      elif criterios[:2] in {'e:','E:'}:
         regra_regex = criterios[2:]
      elif criterios[:2] in {'l:','L:'}:
         regra_like = criterios[2:]
         regra_regex = UtilExtracaoRe.like_to_regex(regra_like)
      return regra_like, regra_regex

  # usado para aplicação de critérios simples como a chamada de um serviço
  # aplica a remoção dos critérios de remoção e avalia se usa o PesquisaBR ou critérios Regex ou Like 
  # todo - grifar ser aplicado no texto original - para isso o remover deve retornar o texto original também
  @classmethod
  def aplicar_criterios(self, texto = None, criterios = None, detalhar = False, extrair = True, grifar = False):
      if (not texto) or (not criterios):
         if detalhar:
            return {'retorno': False, 'criterios': '', 'texto': ''}
         return {'retorno': False}
      ini_processamento = datetime.now()
      rpbr = RegrasPesquisaBR()
      texto_limpo = UtilExtracaoRe.processar_texto(texto)
      texto_r, criterios_r = rpbr.remover_texto_criterio(texto = texto_limpo, criterios = criterios )
      _texto = texto_r or texto
      texto_limpo = texto_r or texto_limpo 
      _criterios = criterios_r or str(criterios)
      # regex ou like
      regra_like, regra_regex = self.regra_like_regex(_criterios)
      # verifica se existe o texto processado para regex
      if regra_regex:
         # print('texto_limpo: ', texto_limpo)
         extracoes = UtilExtracaoRe.extrair_regex(texto= texto_limpo, criterio=regra_regex)
         if type(extracoes) is str:
            return {'erros': extracoes, 'criterios': regra_regex }
         res = {'retorno' : any(extracoes)}
         if extrair:
            res['extracao'] = extracoes
         # grifar não está preparado para dict em regras
         if grifar:
            res['texto_grifado'] = UtilExtracaoRe.grifar_textos(texto_original=texto_limpo, extracoes=extracoes)
         if detalhar:
            res['criterios'] = regra_regex
            res['texto'] = texto_limpo
            res['criterios_analise'] = criterios
            if regra_like:
               res['criterios_like'] = regra_like
         return self.registrar_tempo_segundos(res, ini_processamento)
      # verifica os critérios no texto
      pb = PesquisaBR(texto=_texto, criterios=_criterios, print_debug=False)
      if pb.erros:
         res = {'retorno': None, 'erros': pb.erros, 'criterios': pb.criterios }
         return self.registrar_tempo_segundos(res, ini_processamento)
      res = {'retorno': pb.retorno()}
      if detalhar:
         if type(pb.tokens_texto) is dict:
            _texto_processado = {k: ' '.join(v) for k, v in pb.tokens_texto.items()}
         elif type(texto) is list:
            _texto_processado = [' '.join(t) for t in pb.tokens_texto]
         else:
            _texto_processado = ' '.join(pb.tokens_texto)
         res['texto'] = _texto_processado
         res['criterios_aon'] = pb.criterios_and_or_not
         res['criterios'] = pb.criterios
         res['criterios_analise'] = criterios
      if grifar:
         if type(_texto) is dict:
            _texto_grifado = {}
            for c, v in _texto.items():
                _texto_grifado[c] = pb.grifar_criterios(v).replace('\n','<br>')
         elif type(_texto) is list:
            _texto_grifado = [pb.grifar_criterios(t).replace('\n','<br>') for t in _texto]
         else:
            _texto_grifado = pb.grifar_criterios(_texto).replace('\n','<br>')
         res['texto_grifado'] = _texto_grifado      
      return self.registrar_tempo_segundos(res, ini_processamento)

  # aplica as regras na ordem dos grupos, cada grupo só é testado até retornar TRUE
  # retorna o texto processado, os rótulos e as extrações (texto, rotulos, extracões), a regra identificada
  # o texto é retornado caso o detalhar seja true, para evitar retorno sem necessidade
  # a regra identificada é incluída no retorno no caso do detalhar=1/True
  # dicionário: {'rotulos','extracoes','texto','regras'}
  # qtd_cabecalho e qtd_rodape serve para indicar que a regra será aplicada apenas no início, fim ou início e fim do texto
  # primeiro_do_grupo = true indica que ao retornar um rótulo do grupo, ignora outras regras do grupo
  #                     false continua aplicando todas as regras do grupo retornando todos os rótulos possíveis
  # cabeçalhos e rodapés são analisados depois da remoção das transcrições/aspas
  def aplicar_regras(self, texto = None, primeiro_do_grupo = True, detalhar = False, extrair = False):
      if (not self.regras) or (not texto):
         return {'rotulos':[], 'extracoes': []}
      ini_processamento = datetime.now()
      grupos_ok = []
      retorno_rotulos = []
      retorno_extracoes = []
      retorno_erros = []
      retorno_regras = []
      # cria um dicionário com objetos com texto mapeado para o caso de uso de cabeçahos e rodapés, para não ficar reprocessando o texto o tempo todo
      # caso exista um objeto no dicionário com o texto já processado da mesma forma (mesmo cabeçalho e rodapé), usa ele.
      pbr = PesquisaBR(texto=texto)
      # caches de texto para análise
      if type(pbr.tokens_texto) is dict:
         texto_processado = {}  
         for c, v in pbr.tokens_texto.items():
             texto_processado[c] = ' '.join(v)
      else:
         texto_processado = ' '.join(pbr.tokens_texto)
      #print('PROCESSADO: ', texto_processado)
      texto_limpo = pbr.texto # usado para análise do remover
      texto_processado_sem_aspas = None # vai armazenar o texto caso algum critério remova transcrições/aspas
      texto_re_processado = None # vai armazenar o texto processado para regex se for usado
      texto_re_processado_sem_aspas = None # vai armazenar o texto processado para regex sem transcrições/aspas se for usado
      pbrs = {'c0r0': pbr} # objeto com o texto completo - zero cabeçhado e zero rodapé e com possíveis transcrições
      if self.print_debug:
         print(f'Testando {len(self.regras)} regras para o texto: "{texto}"  processado "{texto_processado}" ')
      for r in self.regras:
          regra_detalhe = deepcopy(r) if detalhar else {} # para desvincular do objeto e alterar chaves
          grupo = r.get('grupo','')
          # se o grupo já retornou TRUE, ignora ele 
          # se for para retornar apenas o primeiro 
          # se não for para retornar apenas o primeiro, grupos_ok fica vazio
          if (grupo in grupos_ok):
             continue
          regra = r.get('regra')
          rotulo = r.get('rotulo','')
          _aspas = '' # usado para completar a chave do dicionário de cache
          # verifica se existe critério de remoção de aspas e guarda o texto processado sem citações se não foi processado ainda
          remover_aspas = self.RE_REMOVER_ASPAS.search(regra)
          if remover_aspas:
             _aspas = '_aspas' # usado para completar a chave do dicionário de cache de obj PesquisaBR
             # limpa o critério de remoção de aspas da regra 
             regra = self.RE_REMOVER_ASPAS.sub(' ', regra).strip()
             # guarda o cache do texto sem aspas se for necessário
             if not texto_processado_sem_aspas:
                texto_processado_sem_aspas = self.RE_REMOVER_ENTRE_ASPAS.sub(' ',str(texto))
                pbr = PesquisaBR(texto=texto_processado_sem_aspas)
                texto_processado_sem_aspas = ' '.join(pbr.tokens_texto)
                pbrs['c0r0_aspas'] = pbr # objeto com o texto sem as aspas

          # regex ou like
          regra_like, regra_regex = self.regra_like_regex(regra)
          # verifica se existe o texto processado para regex
          if regra_regex:
             if not texto_re_processado:
                 texto_re_processado = UtilExtracaoRe.processar_texto(texto)
             if remover_aspas and not texto_re_processado_sem_aspas:
                 texto_re_processado_sem_aspas = UtilExtracaoRe.processar_texto(self.RE_REMOVER_ENTRE_ASPAS.sub(' ',str(texto)))
             texto_para_analise = texto_re_processado_sem_aspas if remover_aspas else texto_re_processado
          else:
             texto_para_analise = texto_processado_sem_aspas if remover_aspas else texto_processado
          # prepara o texto a ser analisado de acordo com o cabeçalho e rodapé definidos
          # guarda o texto para uso posterior em outras regras com o mesmo cabeçalho e rodapé
          qtd_cabecalho = r.get('qtd_cabecalho',0)
          qtd_rodape = r.get('qtd_rodape',0)
          # print(f'c{qtd_cabecalho}r{qtd_rodape}{_aspas} >> Regra: {regra}', f'\n -- texto: {texto_para_analise}" ')
          if qtd_cabecalho > len(texto_para_analise) or qtd_rodape>len(texto_para_analise) \
             or (qtd_cabecalho == 0 and qtd_rodape ==0):
             # o texto é ele mesmo, não há corte
             qtd_cabecalho = 0
             qtd_rodape = 0
             regra_detalhe['texto'] = texto_para_analise
          elif qtd_cabecalho>0 and qtd_rodape>0:
             texto_para_analise = texto_para_analise[:qtd_cabecalho] + ' ' + texto_para_analise[-qtd_rodape:]
             regra_detalhe['texto'] = texto_para_analise
          elif qtd_cabecalho>0:
             texto_para_analise = texto_para_analise[:qtd_cabecalho]
             regra_detalhe['texto'] = texto_para_analise
          elif qtd_rodape>0:
             texto_para_analise = texto_para_analise[-qtd_rodape:]
             regra_detalhe['texto'] = texto_para_analise
          else:
             # o texto é ele mesmo, não há corte
             qtd_cabecalho = 0
             qtd_rodape = 0
             regra_detalhe['texto'] = texto_para_analise

          # se a regra está vazia, ignora ela
          if (not regra) or (rotulo in retorno_rotulos):
             continue
          regra_ok = False
          # critério REGEX
          if regra_regex:
             _texto_com_remover, _regra_com_remover = self.remover_texto_criterio(texto=texto_para_analise, criterios=regra_regex)
             texto_para_analise = _texto_com_remover or texto_para_analise
             regra_regex = _regra_com_remover or regra_regex
             retorno = UtilExtracaoRe.extrair_regex(texto= texto_para_analise, criterio=regra_regex)
             if type(retorno) is str:
                retorno_erros.append(retorno)
                retorno = [] 
             regra_ok = any(retorno)
             if extrair:
                # no detalhamento, inclui a extração na regra que a gerou
                if detalhar:
                   regra_detalhe['extracoes'] = retorno
                else:
                   retorno_extracoes.extend(retorno)
             if detalhar:
                regra_detalhe['criterios'] = regra_like or regra_regex
          # critério textual
          else:
            # atualiza o critério para o objeto de pesquisa que já processou o texto
            # o critério muda, mas o texto é o mesmo - aproveita o mapa que está pronto
            # caso exista remoção, é necessário ignorar o cache e usar o texto original com a limpeza básica
            _texto_com_remover, _regra_com_remover = self.remover_texto_criterio(texto=str(texto_limpo), criterios=regra)
            # _texto_com_remover só retorna algo se existe critério de remoção na regra
            # se não tiver texto processado com remoção, segue usando o texto original processado
            if not _texto_com_remover:
              # busca o objeto pronto com o texto recortado ou cria um objeto novo
              _pbr = pbrs.get(f'c{qtd_cabecalho}r{qtd_rodape}{_aspas}')
              if not _pbr:
                 _pbr = PesquisaBR(texto=texto_para_analise)
                 pbrs[f'c{qtd_cabecalho}r{qtd_rodape}{_aspas}'] = _pbr
            else:
              # a remoção exige um novo objeto de pesquisa que não é reaproveitado pois a variação pode ser grande
              # a única remoção reaproveitada é a de aspas, pois pode ser igual em várias regras
              if self.print_debug:
                 print(f'Removendo trecho - texto final:"{_texto_com_remover}" - critérios: "{_regra_com_remover}"')
              _pbr = PesquisaBR(texto=_texto_com_remover)
              regra = _regra_com_remover
            # registra no objeto novo ou do cache o critério de pesquisa
            _pbr.novo_criterio(regra)
            if _pbr.erros:
                retorno_erros.append(_pbr.erros)
            if self.print_debug:
               print(f'Testando grupo: [{grupo}] com rótulo: [{rotulo}] e regra: {regra}')
               _pbr.print_resumo()
            regra_ok = _pbr.retorno()
            if detalhar:
               regra_detalhe['criterios'] = _pbr.criterios
               regra_detalhe['criterios_aon'] = _pbr.criterios_and_or_not

          # com a regra ok, registra o rótulo para retorno
          if regra_ok:
             # verifica se controla apenas um rótulo por grupo (padrão)             
             if primeiro_do_grupo:
                 # indica que o grupo já foi retornado, não retornando outras regras do grupo
                 grupos_ok.append(grupo)
             # inclui o rótulo no retorno
             retorno_rotulos.append(rotulo)
             # verifica se é retorno detalhado e inclui a regra que incluiu o rótulo no retorno
             if detalhar: 
                 retorno_regras.append(regra_detalhe)
      # finalizando o retorno
      res = {'rotulos':retorno_rotulos}
      if any(retorno_erros):
         res['erros'] = retorno_erros
      # no detalhar, a extração fica dentro das regras
      if extrair and not detalhar:
         res['extracoes'] = retorno_extracoes
      if not detalhar:
         return self.registrar_tempo_segundos(res, ini_processamento)
      # detalhando
      res['texto'] = texto_processado
      if texto_re_processado:
         res['texto_regex'] = texto_re_processado
      res['texto_analise'] = texto
      res['regras'] = retorno_regras
      res['qtd_regras'] = len(self.regras)
      self.registrar_tempo_segundos(res, ini_processamento)
      return res

  @classmethod
  def registrar_tempo_segundos(self, dados, ini_processamento):
      dados['tempo'] = round((datetime.now()- ini_processamento).total_seconds(), 3)
      return dados

  @classmethod
  def tempo_segundos(self, ini_processamento):
      return round((datetime.now()- ini_processamento).total_seconds(), 3)

  # identifica no critério operadores de remoção de texto
  # pode-se usar:
  #      remover(um texto qualquer)
  #      remover(aspas) - remove textos entre aspas
  # assume-se que o texto já está pré-processado e o conteúdo das aspas já foi removido
  # pois o conteúdo das aspas deve ser removido antes do pré-processamento do texto já que só tokens são 
  # mantidos após o processamento
  # Como usar o operador remover(texto)
  # todo o texto dentro dos parênteses serão removidos do texto processado
  # - podem ser usados curingas no trecho de remoção, são eles:
  # - $ ou * - de 0 a 100 caracteres quaisquer
  # - ? - um caractere de letra ou número opcional
  # - & - um caractere de letra ou número obrigatório
  # - # - um a 10 caracteres que não sejam letra nem número (pontuação, início ou final de texto, espaço, etc)
  # - *# - caracteres até um símbolo (pontuação, início ou final de texto, espaço, etc)
  # - *## - caracteres até uma quebra de linha
  # - % - aspas, parênteses, chaves ou colchetes (citações/explicações em geral)
  # - " - aspas normal
  # Exemplos:
  # - remover(juizado*grau) >> remove juizado[até 100 caracteres quaisquer]grau
  # - remover(%**%) >> remove o que estiver entre parênteses, aspas, colchetes ou chaves (até 200 caracteres - 100 para cada *)
  # - remover("*") >> remove o que estiver entre aspas até 100 caracteres entre a abertura e o fechamento
  # - remover(#artigo&#) >> remove artigo seguido de uma letra ou número com algum símbolo antes e depois (pontuação, espaço, etc) - exemplo do que seria removido: artigos, artigo1, artigo 
  RE_REMOVER = re.compile(r'remover\([^\)]*\)', flags=re.IGNORECASE)
  RE_REMOVER_ASPAS = re.compile(r'remover\(\s*aspas\s*\)', flags=re.IGNORECASE)
  RE_REMOVER_ENTRE_ASPAS = re.compile('("[^"]*")'+"|('[^']*')")
  @classmethod
  def remover_texto_criterio(self,  texto: str ='', criterios: str = ''):
      # se o texto for um dict de {'campo': texto}
      # retorna cada chave com o valor processado
      if type(texto) is dict:
         _textos = dict({})
         for c, t in texto.items():
            _textos[c], _criterios = self.remover_texto_criterio(texto = t, criterios = criterios)
            _textos[c] = _textos[c].strip() if _textos[c] else None
            # não tendo critérios de remoção, já retorna o padrão None
            if not _criterios:
               return None, None
         return _textos, _criterios

      if len(texto) == 0 or len(criterios)==0:
         return None,None
      remocoes = self.RE_REMOVER.findall(criterios)
      if len(remocoes) == 0:
         return None,None
      # padroniza as aspas do texto
      _texto = self.padronizar_aspas(texto)
      # remove as aspas do texto se solicitado - o ideal é já vir removido e o texto deveria estar
      # pré-processado, ou seja, nem tem mais aspas nos tokens
      # mas para permitir usos além do analisador padrão de regras, ele pode remover aspas se 
      # receber esse comando no critério analisado 
      if self.RE_REMOVER_ASPAS.search(criterios):      
         _texto, _criterios = self.remover_texto_aspas(_texto, criterios)
      else:
         _criterios = str(criterios)
        
      _pbr = PesquisaBR()
      # removeu aspas e tem critérios de remoção, processa os termos sem curingas
      # remocoes é a lista de critérios de remoções encontrados - um item para cada remover(...)
      for remover in remocoes:
          # [8:-1] para sobrar apenas o que está dentro do remover(...)
          #print('remover raw: ', remover[8:-1])
          #print('remover processado: ', _pbr.processar_texto(remover[8:-1]))
          remover = _pbr.processar_texto( self.padronizar_aspas(remover[8:-1]))
          #print('remover: ', remover)
          # com os tokens limpos, faz a preparação do REGEX de substituição com os curingas
          if remover:
            #print('raw remover: ', remover)
            re_remover = self.preparar_regex_remocao(remover)
            if type(re_remover) is str:
              #print('replace remover: ', re_remover)
              _texto = _texto.replace(re_remover,' ')
            else:
              #print('regex remover: ', re_remover)
              #print('texto remover: ', _texto)
              _texto = re_remover.sub(' ',_texto)
              #print('texto removido: ', _texto)
      # retira os operadores de remoção dos critérios remover(...)
      _criterios = self.RE_REMOVER.sub(' ',_criterios)
      return _texto.strip(), _criterios.strip()

  # retorna o texto e o critério com o trecho entre aspas limpo se for solicitado nos critérios
  # ex. de critérios:  casa ADJ2 papel remover(aspas)
  # retorna o texto sem o conteúdo entre as aspas e o critério sem remover(aspas)
  @classmethod
  def remover_texto_aspas(self,  texto: str ='', criterios: str = ''):
      if self.RE_REMOVER_ASPAS.search(criterios):
         return self.RE_REMOVER_ENTRE_ASPAS.sub(' ',str(texto).strip()), self.RE_REMOVER_ASPAS.sub(' ',str(criterios)).strip()
      return None,None

  # retorna vazio caso não tenha curingas pois não precisa de regex
  RE_CURINGAS_REMOCAO = re.compile(r'[\?$%&#*]')
  @classmethod
  def preparar_regex_remocao(self, remover: str = ''):
      if not remover:
          return ''
      if not self.RE_CURINGAS_REMOCAO.search(remover):
          return remover
      remover = str(remover)
      # prepara o regex de remoção  substituindo ? por . 
      # algumas premissas precisam ser analisadas \ e | não podem existir e símbolos do regex serão convertidos para \\ 
      # serão válidos os curingas ?, %, &, #, * ou $ 
      _rgx_remover = remover.replace('\\',' ') # caractere inválido para análise 
      _rgx_remover = _rgx_remover.replace('|',' ') # caractere inválido para análise 
      _rgx_remover = _rgx_remover.replace('$','*') # padroniza para * 
      _rgx_remover = _rgx_remover.replace('[',r'\[').replace(']',r'\]')
      _rgx_remover = _rgx_remover.replace('.',r'\.').replace('-','\-')
      _rgx_remover = _rgx_remover.replace('^',r'\^').replace('(',r'\(')
      # aspas com asterisco antes 
      _rgx_remover = _rgx_remover.replace('*"',r'[^"]{1,100}"')
      # citações com asterisco antes - verifica aspas, parênteses, colchetes e chaves
      _rgx_remover = _rgx_remover.replace('*%',r'[^"]{1,100}["\[\]\(\){}\|]')
      # citações
      _rgx_remover = _rgx_remover.replace('%',r'["\[\]\(\){}\|]')
      # curinga composto *## significa até o fim da linha
      _rgx_remover = _rgx_remover.replace('*##',r'.*[^\r\n]')
      # curinga composto *# significa até o fim da palavra 
      _rgx_remover = _rgx_remover.replace('*#','[a-z0-9]*[^a-z0-9]{1,10}')
      # curingas normais 
      _rgx_remover = _rgx_remover.replace('*','.{0,100}')
      _rgx_remover = _rgx_remover.replace('?','[a-z0-9]?')
      _rgx_remover = _rgx_remover.replace('&','[a-z0-9]')
      _rgx_remover = _rgx_remover.replace('#','[^a-z0-9]{1,10}')
      return re.compile(_rgx_remover)

  # usado para retornar os trechos de critérios de remoção para análise ou apresentação na tela
  @classmethod
  def retornar_criterios_remocao(self, criterios):
      remocoes = self.RE_REMOVER.findall(criterios)
      return ' '.join(remocoes)

  @classmethod
  def padronizar_aspas(self, texto):
      return str(texto).replace('“','"').replace('”','"').replace("'",'"')

################################################################################
################################################################################
if __name__ == "__main__":
    print('##############################################')
    print('>> TESTE BÁSICOS - REGRAS ')
    pb=RegrasPesquisaBR()
    texto = 'Teste de texto removido e com trecho entre aspas "esse trecho tem que sair" ok'
    criterios = 'casa adj2 papel remover(removidos) remover(aspas)'
    print(pb.remover_texto_criterio(texto = texto, criterios = criterios))

    regras = ['']
