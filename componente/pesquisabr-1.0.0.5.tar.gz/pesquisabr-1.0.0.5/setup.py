import setuptools
#
# Para gerar o dist, executar: 
#   python setup.py sdist 

setuptools.setup(
    name="pesquisabr",
    version= '1.0.0.5',
    author="Luiz Anísio",
    author_email="",
    description="Projeto para pesquisa textual",
    long_description='Pacote base para os projetos com pesquisa textual avançada',
    long_description_content_type="text/markdown",
    url="https://github.com/luizanisio/PesquisaTextualBR",
    packages = setuptools.find_packages(),
    package_data={'':['*.md','LICENCE','*.py','*.sql'],},
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: MIT License",
        "Operating System :: OS Independent",
    ],
)

### NOTAS DE VERSÕES 
''' 
 1.0.0.5 - singularização aprimorada com lista de palavras ignoradas no falso plural
         - melhoria dos testes para as singularizações
'''