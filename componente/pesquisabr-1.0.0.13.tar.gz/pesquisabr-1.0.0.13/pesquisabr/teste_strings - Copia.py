from pesquisabr import PesquisaBR
import re
from unicodedata import normalize

RE_TOKENS = re.compile(r'(\s)|([0-9]+)|([a-zA-Z]+)|(\n+)|(\W|.)')

texto = ' . / ~[]   qualquer coisa A casa de Papel é muito massa de legal de mais ! : "teste entre aspas" número 1.234,344 11/12/2012 § <br> legal '

pb = PesquisaBR(texto=texto)

# retorna o ajuste necessário para cada posição 
# o ajuste é o número que precisa ser deslocado para voltar ao normal
def processar_posicoes_regex(texto, regex, sub, posicoes):
    deslocamento_regex = 0
    for match in regex.finditer(texto):
        _ini, _fim = match.span() 
        _txt = texto[_ini:_fim]
        _sub = regex.sub(sub,_txt)
        deslocamento_inicio, deslocamento_fim = 0, 0
        if _sub.strip() != '':
            deslocamento_inicio = len(_sub) - len(_sub.lstrip())
            deslocamento_fim = len(_sub) - len(_sub.rstrip())
            diferenca_fim = _fim - _ini - len(_sub) + deslocamento_fim
        else:
            diferenca_fim = _fim - _ini - len(_sub)
        # dif é o quanto deve somar para ficar na posição original
        if deslocamento_inicio + diferenca_fim != 0:
            _ini -= deslocamento_regex
            _fim -= deslocamento_regex
            _novas = []
            for _ in posicoes:
                if _ >= _fim - diferenca_fim:
                    _novas.append(_ + diferenca_fim)
                elif _ >= _ini:
                    _novas.append(_ + deslocamento_inicio)
                else:
                    _novas.append(_)
            posicoes = _novas
            #posicoes = [_ + deslocamento_inicio if _ >= _ini else _  for _ in posicoes]
            #posicoes = [_ + diferenca_fim if _ >= _fim - diferenca_fim  else _  for _ in posicoes]
            print(f'[{_txt}] \t [{_sub}] \t ', _ini, _fim, deslocamento_inicio, diferenca_fim, deslocamento_regex)
            deslocamento_regex += len(_txt) - len(_sub)

    _texto = regex.sub(sub, texto)
    # corrige as posições posteriores pois foram afetadas
    return _texto, posicoes

def processar_posicoes_tokens(texto):
    _texto = pb.RE_UNICODE.sub('', normalize("NFD", str(texto) )).lower()
    posicoes = [i for i in range(len(_texto))]
    # quebras de linha
    _texto, posicoes = processar_posicoes_regex(_texto, pb.RE_QUEBRA,' ', posicoes)
    # parágrafo
    _texto, posicoes = processar_posicoes_regex(texto, re.compile('§'),' paragrafo ', posicoes)
    # normalização de símbolos
    _texto = pb.normalizar_simbolos(_texto)
    # números
    _texto, posicoes = processar_posicoes_regex(_texto, pb.RE_NUMEROS,'\\1\\3', posicoes)
    _texto, posicoes = processar_posicoes_regex(_texto, pb.RE_NUMEROS_ESPACO,'\\1\\3', posicoes)
    # quebras de linha
    _texto, posicoes = processar_posicoes_regex(_texto, pb.RE_QUEBRA,' ', posicoes)

    print('Posições antigas: ',' '.join( [str(i).ljust(3) for i in range(len(_texto))]) )
    print('Posições novas  : ', ' '.join( [str(i).ljust(3) for i in posicoes]) )
    print('Texto     : ', texto)
    print('Texto novo: ', _texto.replace('\n','|'))

    # quebra os tokens finais
    _tokens = []
    for match in pb.RE_TOKENS.finditer(_texto):
        _ini, _fim = match.span()
        _txt = _texto[_ini:_fim]
        if _txt not in ('?','$','',' '):
            # busca as correções dessa posição
            novo_ini = posicoes[_ini]
            novo_fim = posicoes[_fim]
            novo_txt = texto[novo_ini:novo_fim]
            novo_txt = f'"{novo_txt}"'.replace('\n','|').ljust(10)
            _txt = f'"{_txt}"'.replace('\n','|').ljust(10)
            _tokens.append((_txt, novo_txt, _ini, _fim, novo_ini, novo_fim))
            print(f'{_txt} \t {novo_txt} \t \t {_ini} \t {_fim} \t || \t {novo_ini} \t {novo_fim}')

texto = 'a casa de papel 1.234,33 legal <br> outro  texto § legal'
texto = 'papel § legal <br> nada'
texto = 'legal <br> nada e tudo 1.234,33 outro'
texto = 'a <br> 1234,33 outro'
texto = 'a <br> b <br> c <br> d'
processar_posicoes_tokens(texto)
exit()
#print(pb.tokens_texto)
texto = ' texto § legal'
texto = pb.normalizar_simbolos(texto)
REG = re.compile('§')
for match in REG.finditer(texto):
    _ini, _fim = match.span()
    _txt = texto[_ini:_fim]    
    _sub = REG.sub(' paragrafo ',_txt)
    print( f'{_ini} -> {_fim} :: {_txt} :: {_sub}')

pos = processar_posicoes_regex(texto, REG, ' paragrafo ', [])
print(pos)    