class PesquisaBRTestes():
    @staticmethod
    def testes_completos():
        for t in TESTES_COMPLETOS:
            yield t

    @staticmethod
    def testes_basicos(resumido = True):
        lista = TESTES_BASICOS if resumido else TESTES_BASICOS+TESTES_COM_REMOVER_PROD+TESTES_USADOS_PROD
        for t in lista:
            yield t

    @staticmethod
    def testes_extracao():
        lista = TESTES_EXTRACAO 
        for t in lista:
            yield t

    @staticmethod
    def testes_retorno_completo():
        lista = TESTES_RETORNO_COMPLETO
        for t in lista:
            yield t

    @staticmethod
    def testes_texto():
        for t in TESTES_TEXTOS:
            yield t

TEXTO_BASE = "a casa de papel é um seriado bem interessante numero123"

TESTES_BASICOS = [
            {'texto':'essa teste simples','criterio':'(esse OU essa OU nada) ADJC teste PROXC simples','retorno':True},
            {'texto':'esse teste simples','criterio':'("teste simples") ("esse teste") ("esse teste simples")','retorno':True},
            {'texto':'esse essa \n teste \n simples','criterio':'(esse OU essa) teste simples','retorno':True},
            {'texto':'essa \n teste \n simples','criterio':'(esse OU essa) ADJ teste ADJ simples','retorno':True},
            {'texto':'outro \n teste \n simples','criterio':'(esse OU esso OU outro OU outra OU essa) ADJ teste ADJ simples','retorno':True},
            {'texto':'outro \n teste \n simples','criterio':'(esse OU esso OU outro OU outra OU essa) ADJC teste ADJ simples','retorno':False},
            {'texto':'outro <br> teste <br> simples','criterio':'outro COM teste','retorno':False},
            {'texto':'outro \n teste \n simples','criterio':'outro COM simples','retorno':False},
            {'texto':'outro <br> teste \n simples','criterio':'outro COM2 teste','retorno':True},
            {'texto':'outro \n teste \n simples','criterio':'outro COM2 simples','retorno':False},
            {'texto':'outro \n teste <br> simples','criterio':'outro COM3 simples','retorno':True},
            {'texto':'outro \n teste <br> simples','criterio':'(outro prox2 simples) e (simples prox2 outro) e (simples prox1 teste)','retorno':True},
            {'texto':'outro \n teste <br> simples','criterio':'(outro proxc2 simples) OU (simples proxc2 outro) OU (simples proxc1 teste)','retorno':False},
            {'texto':'outro \n teste <br> simples','criterio':'(outro adj2 simples) e (outro adj1 teste) e ("outro teste") e (teste ADJ simples)','retorno':True},
            {'texto':'outro \n teste <br> simples','criterio':'(outro adjc2 simples) OU (outro adjc teste) OU (teste adjc2 simples)','retorno':False},
            {'texto':'outro \n teste <br> simples','criterio':'(outro adj2 simples) e (teste adj simples)','retorno':True},
            {'texto':'outro \n teste <br> simples','criterio':'teste E (teste adjc1 simples)','retorno':False},
            {'texto':'outro \n teste <br> simples','criterio':'(NÃO casa) (Não nada) (não "tudo") (nao "não")','retorno':True},
            {'texto':'outro \n teste <br> simples','criterio':'(outro não "Não") (outro (não "Não"))','retorno':True},
            {'texto':'outro \n teste <br> simples','criterio':'teste NÃO (teste adjc1 simples)','retorno':True},
            {'texto':'esse é um teste para negação de texto','criterio':'teste NÃO (negação)','retorno':False},
            {'texto':'esse é um teste para negação de texto','criterio':'teste NÃO negação NÃO texto','retorno':False},
            {'texto':'esse é um teste para negação de texto','criterio':'teste NÃO (negação OU texto)','retorno':False},
            {'texto':'esse é um teste para negação de texto','criterio':'teste NÃO (palavra termo casa)','retorno':True},
            {'texto':'esse é um teste para negação de texto','criterio':'teste NÃO palavra NÃO termo NÃO casa','retorno':True},
            {'texto':'teste de termos<br> testa seguidos','criterio':'(teste ou testa) com (seguidos)','retorno':True},
           ]

TESTES_USADOS_PROD = [
            {'texto': 'cópia da petição de fls. 200-200215 ao Juízo 200-200 de primeira', 'criterio': "'cópia' adjc15 Juízo adjc10 primeira", 'retorno': True},
            {'texto': 'cópia da petição de fls. 200-200215 <br><br>ao Juízo 200-200 de primeira', 'criterio': "'cópia' adjc15 Juízo adjc10 primeira", 'retorno': False},
            {'texto': 'cópia da petição de fls. 200-200215 ao Juízo 200-200 de primeira', 'criterio': "'cópia' proxc15 Juízo adjc10 primeira", 'retorno': True}, 
            {'texto': 'teste de texto agravo não provido ou sei lá', 'criterio': 'teste adj4 agravo', 'retorno': True}, 
            {'texto': 'a casa<br><br>grande', 'criterio': 'grande proxc10 casa', 'retorno': False}, 
            {'texto': 'nesse contexto, indefiro a liminar entre outras coisas mais, solicito e quero muito mais quaisquer informações', 'criterio': 'indefir$ adj4 liminar (solicit$ adj5 informações)', 'retorno': False}, 
            {'texto': 'confirmando que o dano moral que pode ser estético foi presumida a', 'criterio': "'dano moral' adj5 estético não (presumido? ou presumida?)", 'retorno': False}, 
            {'texto': 'Solicitem-se, ao Juízo da 1ª Vara Criminal de Suzano-SP, informações', 'criterio': "('Solicito' ou 'solicite' ou 'solicite$' ou 'solicitem$' ou 'Solicitando' ou 'Requisit$' ou 'Necessário') adj15  'informações'", 'retorno': True}, 
            {'texto': 'teste de texto agravo não provido ou sei lá', 'criterio': 'r:(agravo\\\\s+a)', 'retorno': False}, 
            {'texto': 'teste de texto agravo foi provido ou <br>sei lá', 'criterio': "agravo adj5 provido nao ('nao provido')", 'retorno': True}, 
            {'texto': 'a casa<br><br>grande', 'criterio': 'casa adjc10 grande', 'retorno': False}, 
            {'texto': 'conforme encaminho esses autos para turma julgadora do juizo de retratacao', 'criterio': '(encaminh$ ou remet$ ou remessa) adj2 (autos ou processo ou feito) adj2 Turma adj2 julgadora adj4 juízo adj2 retratação', 'retorno': True}, 
            {'texto': 'a casa de papel e um filme interessante', 'criterio': '(casa ou apartamento) adj3 papel ou folha', 'retorno': True}, 
            {'texto': 'a casa de bla-bla-bla papel', 'criterio': 'casa ADJ3 papel', 'retorno': False}, 
            {'texto': 'as casas de papel um video interessante', 'criterio': '(casa? ou apartamento?) adj3 (papel ou folha ou papeis) adj3 (filme ou video) adj2 interessante', 'retorno': True}, 
            {'texto': 'recurso quase especial dá-se um grande provimento no agravo em recurso especial', 'criterio': "(RESP ou 'recurso especial') ou (Dá-se ou dou) adj4 provimento adj3 'agravo em recurso especial'", 'retorno': True}, 
            {'texto': 'a turma resolveu conceder um habeas corpus por meio desse oficio legal', 'criterio': "(conceder adj2 'habeas corpus' adj4 'ofício')", 'retorno': True}, 
            {'texto': 'a casa de papel <br><br>o papel dele é interessante na série', 'criterio': 'casa COM papel COM serie', 'retorno': False}, 
            {'texto': 'a casa de papel é uma série muito interessante', 'criterio': 'casa COM papel COM serie COM interessante', 'retorno': True}, 
            {'texto': 'sendo assim, ou não, determino imediata remessa do processo feito neste órgão sempre julgador  do juízo de retratação', 'criterio': 'Determino adj4 (encaminhamento ou remessa) adj4 (autos ou processo ou feito) adj4 (órgão ou turma) adj2 julgador$ adj4 juízo adj2 retratação', 'retorno': True}, 
            {'texto': 'casas de da do papel', 'criterio': '(casas ou apartamento) adj3 (papel ou folha ou papeis)', 'retorno': False}, 
            {'texto': 'a redução do estômago foi bem sucedida', 'criterio': '(bariatrica ou obesidade ou gastroplastia) ou (redu$ adj2 estoma$)', 'retorno': True}, 
            {'texto': 'a turma resolveu conceder um habeas corpus por meio desse oficio legal', 'criterio': "conceder adj2 'habeas corpus' adj4 'ofício'", 'retorno': True}, 
            {'texto': 'sendo assim, ou não, determino imediato encaminhamento dos autos deste<br>processo ao órgão sempre julgador  do juízo de retratação', 'criterio': 'Determino adj4 (encaminhamento ou remessa) adj4 (autos ou processo ou feito) adj4 (órgão ou turma) adj2 julgador$ adj4 juízo adj2 retratação', 'retorno': True}, 
            {'texto': 'confirmando que o dano moral que pode ser estético foi assumido a', 'criterio': "'dano moral' adj5 estético não (presumido? ou presumida?)", 'retorno': True}, 
            {'texto': 'dano  bla material', 'criterio': '(dano ou moral) adj2 (dano ou material)', 'retorno': True}, 
            {'texto': 'o apartamento de folha e um filme interessante', 'criterio': '(casa ou apartamento) adj3 papel ou folha adj3 filme', 'retorno': True}, 
            {'texto': 'teste de texto agravo não provido ou sei lá', 'criterio': "agravo adj5 provido nao ('nao provido')", 'retorno': False}, 
            {'texto': 'a casa de ferro é um teste', 'criterio': 'casa ADJ1 de ADJ1 ferro e teste', 'retorno': True}, 
            {'texto': "'sendo assim, ou não, determino imediata remessa do processo feito nesta fantástica turma sempre julgadora para o juízo de retratação'", 'criterio': 'Determino adj4 (encaminhamento ou remessa) adj4 (autos ou processo ou feito) adj4 (órgão ou turma) adj2 julgador$ adj4 juízo adj2 retratação', 'retorno': True}, 
            {'texto': 'nesse contexto, indefiro a liminar entre outras coisas mais, solicito muito mais informações', 'criterio': 'indefir$ adj4 liminar (solicit$ adj5 informações)', 'retorno': True}, 
            {'texto': 'ele fez uma bariatrica esse mês', 'criterio': '(bariatrica ou obesidade ou gastroplastia) ou (redu$ adj2 estoma$)', 'retorno': True}, 
            {'texto': 'a b c d e f', 'criterio': '(a adj b adj c) ou (c adj d)', 'retorno': True}, 
            {'texto': 'cópia da petição de fls. 200-200215<br><br> ao Juízo 200-200 de <br><br> primeira', 'criterio': "'cópia' proxc15 Juízo adj10 primeira", 'retorno': False}, 
            {'texto': 'cópia da petição de fls. 200-200215<br><br> ao Juízo 200-200 de <br><br> primeira', 'criterio': "'cópia' prox15 Juízo adj10 primeira", 'retorno': True},
]
# até seq teste 10000003
TESTES_COM_REMOVER_PROD = [
            {'texto': 'termoa termob @#$% termoc termod', 'criterio' : 'termoa adj2 termod remover(termob#termoc)','retorno' : True },
            {'texto': 'testea correlação testeb', 'criterio' : 'testea adj1 testeb remover(cor?ela&&o)','retorno' : True },
            {'texto': 'teste são teste', 'criterio' : 'são remover(s?o)','retorno' : False },
            {'texto': 'teste são teste', 'criterio' : 'são remover(s&o)','retorno' : False },
            {'texto': 'teste de texto termoa termob termoc termod agravo não provido ou sei lá ', 'criterio' : 'teste ADJ4 agravo remover(termo&#)','retorno' : True },
            {'texto': 'termoa aprimoramento termob', 'criterio' : 'remover(#apri*o#) termoa ADJ1 termob','retorno' : True },
            {'texto': 'termoa "aprimoramento bla bla bla bla" termob', 'criterio' : 'remover("*") termoa adj1 termob','retorno' : True },
            {'texto': 'termoa "aprimoramento" "bla bla bla bla" termob (bla) {bla} [BLA]', 'criterio' : 'remover(%*%) termoa adj1 termob NAO  bla','retorno' : True },
            {'texto': 'termoa termob termoc termod termoe termof', 'criterio' : 'remover(termoe) termoa adj1 termoc termoa adj2 termod termod adj1 termof não termob remover(termob) ','retorno' : True },
            {'texto': 'termoa termob termoc <br> termod termoe termof', 'criterio' : 'remover(termoe) termoa adj1 termoc não (termoa com termod) termod adj1 termof não termob remover(termob) ','retorno' : True },
            {'texto': 'termoa termob termoc <br> termod termoe termof termog', 'criterio' : 'remover(termob)  remover(termoe) termoa adj1 termoc (termoa com termoc) termod adj2 termog não termob não termoe não remover','retorno' : True },
            {'texto': 'bla bla bla solicitou aplicacao de medida protetiva do juizo de 1º grau', 'criterio' : 'Solicito COM juízo COM 1º','retorno' : False },
            {'texto': 'bla bla bla solicito aplicacao de medida protetiva do juizo de 1º grau', 'criterio' : 'Solicito COM juízo COM 1º','retorno' : True },
            {'texto': 'vitima solicita aplicacao de medida protetiva do juizo de 1º grau', 'criterio' : 'Solicito COM juízo COM 1º','retorno' : False },
            {'texto': 'bla bla bla solicito aplicacao de medida protetiva do prejuizo de 1º grau', 'criterio' : 'Solicito COM juízo COM 1º','retorno' : False },
            {'texto': 'bla bla bla solicitou aplicacao de medida protetiva do juizo de 1º grau', 'criterio' : 'Solicito$ COM juízo COM 1º','retorno' : True },
            {'texto': 'bla bla bla solicitou aplicacao de medida protetiva do juizo de 1º grau', 'criterio' : 'Solicito$ ADJC10 juízo ADJC10 1º','retorno' : True },
            {'texto': 'bla bla bla solicitou aplicacao de medida protetiva\ndo juizo de 1º grau', 'criterio' : 'Solicito$ ADJC10 juízo ADJC10 1º','retorno' : False },
            {'texto': 'bla solicitou juizo primo teste', 'criterio' : 'Solicito COM juízo COM primo','retorno' : False },
            {'texto': 'bla solicitou juizo primo teste', 'criterio' : 'Solicitou COM juízo COM primo','retorno' : True },
            {'texto': 'bla solicitou juizo primo 1º teste', 'criterio' : 'Solicitou COM juízo COM 1','retorno' : True },
]

TESTES_COMPLETOS = TESTES_BASICOS + TESTES_USADOS_PROD + TESTES_COM_REMOVER_PROD + [
                {"texto":"falha do teste (texto simples para usar de teste de quebra quando necessário - colocar false como esperado e o teste quebra)", "criterio":"falha adj1 do adj1 teste", "retorno": True },
                {'texto':'esse essa teste simples', 'criterio':'esse NÃO essa', 'retorno':False},
                {'texto':'esse essa teste simples', 'criterio':'(esse OU essa) teste simples', 'retorno':True },
                {'texto':'esse essa teste simples', 'criterio':'esse ADJ2 teste ADJ1 simples', 'retorno':True },
                {'texto': 'áéíóúàâôçÁÉÍÓÚÀÂÔÇ Üü texto123', 'criterio':'texto 123 uu aeiouaaocaeiouaaoc', 'retorno': True},
                {'texto': TEXTO_BASE, 'criterio': "casa adj2 papel", 'retorno' : True},
                {'texto': TEXTO_BASE, 'criterio': "'numero 123' prox3 interessante", 'retorno' : True},
                {'texto': TEXTO_BASE, 'criterio': "casa adj6 seriado", 'retorno' : True},
                {'texto': TEXTO_BASE, 'criterio': "seriado prox3 papel", 'retorno' : True},
                {'texto': TEXTO_BASE, 'criterio': "casa adj3 seriado", 'retorno' : False},
                {'texto': TEXTO_BASE, 'criterio': "(casa prox4 seriado) ou (seriado adj1 interessante)", 'retorno' : False},
                {'texto': TEXTO_BASE, 'criterio': "(casa prox4 seriado) ou (seriado adj1 interessante) ou uns", 'retorno' : True},
                {'texto': TEXTO_BASE, 'criterio': "pape$ ou seria$", 'retorno' : True},
                {'texto': {'a':TEXTO_BASE,'b': 'segundo'}, 'criterio': "(casa papel) e segund$", 'retorno' : True},
                {'texto': 'esses textos \ntem\n os e literais para uns testes sorridente', 'criterio': "texto com literal", 'retorno' : False},
                {'texto': 'esses textos \ntem\n os e literais para uns testes sorridente', 'criterio': "texto com2 literal", 'retorno' : False},
                {'texto': 'esses textos \ntem\n os e literais para uns testes sorridente', 'criterio': "texto com3 literal", 'retorno' : True},
                {'texto': {'a':TEXTO_BASE,'b': 'segundo'}, 'criterio': "(casa papel) com segund$", 'retorno' : False},
                {'texto': {'a':TEXTO_BASE,'b': 'segundo'}, 'criterio': "(casa papel) e segund$.b.", 'retorno' : True},
                {'texto': {'a':TEXTO_BASE,'b': 'segundo'}, 'criterio': "(casa papel).a. e segund$.b. e 'casa de papel'.a. (seriado segundo) ", 'retorno' : True},
                {'texto': {'a':TEXTO_BASE,'b': 'segundo texto com o número 1234'}, 'criterio': "(casa papel) e segund$.b. e 1234.b>=. e 123.b>. e 12345.b<=. ", 'retorno' : True},
                {'texto': {'a':TEXTO_BASE,'b': 'segundo texto com o número 1234'}, 'criterio': "(casa papel) e segund$.b. e 1234.b>=. e @b>'123' e @b<=12345 ", 'retorno' : True},
                {'texto': {'a':TEXTO_BASE,'b': '12 123 1 13 1234'}, 'criterio': " (1235.b>. ou 1236.b>.) ou @b>'12345' ", 'retorno' : False},
                {'texto': {'a':TEXTO_BASE,'b': 'a aa b '}, 'criterio': " (ddd.b>. ou bbbb.b>.) ou @b>'ccc' ", 'retorno' : False},
                {'texto': "o instituto nacional de seguridade social fez um teste com texto literal", 'criterio' : 'texto com literais (teste OU testa) ("inss" ou "CaSa de pApél")', 'retorno': True},
                {"texto":"	teste de texto agravo não provido ou sei lá	", "criterio":"	teste adj4 agravo	", "retorno":	True	},
                {"texto":"	a casa<br>grande	", "criterio":"	grande proxc10 casa	", "retorno":	False	},
                {"texto":"	nesse contexto, indefiro a liminar entre outras coisas mais, solicito e quero muito mais quaisquer informações	", "criterio":"	indefir$ adj4 liminar (solicit$ adj5 informações)	", "retorno":	False	},
                {"texto":"	confirmando que o dano moral que pode ser estético foi presumida a	", "criterio":"	'dano moral' adj5 estético não (presumido? ou presumida?)	", "retorno":	False	},
                {"texto":"	conforme encaminho esses autos para turma julgadora do juizo de retratacao	", "criterio":"	(encaminh$ ou remet$ ou remessa) adj2 (autos ou processo ou feito) adj2 Turma adj2 julgadora adj4 juízo adj2 retratação	", "retorno":True	},
                {"texto":"	a casa de papel e um filme interessante	", "criterio":"	(casa ou apartamento) adj3 papel ou folha	", "retorno":	True	},
                {"texto":"	teste de texto agravo foi provido ou sei lá	", "criterio":"	agravo adj5 provido nao ('nao provido')	", "retorno":	True	},
                {"texto":"	a casa<br>grande	", "criterio":"	casa adjc10 grande	", "retorno":	0	},
                {"texto":"	as casas de papel um video interessante	", "criterio":"	(casa? ou apartamento?) adj3 papel ou folha ou papeis adj3 filme ou video adj2 interessante	", "retorno":	True	},
                {"texto":"	recurso quase especial dá-se um grande provimento no agravo em recurso especial	", "criterio":"	(RESP ou 'recurso especial') ou (Dá-se ou dou) adj4 provimento adj3 'agravo em recurso especial'	", "retorno":	True	},
                {"texto":"	a turma resolveu conceder um habeas corpus por meio desse oficio legal	", "criterio":"	(conceder adj2 'habeas corpus' adj4 'ofício')	", "retorno":	True	},
                {"texto":"	a casa de papel <br>o papel dele é interessante na série	", "criterio":"	casa COM papel COM serie	", "retorno":	False	},
                {"texto":"	a casa de papel é uma série muito interessante	", "criterio":"	casa COM papel COM serie COM interessante	", "retorno":	True	},
                {"texto":"	sendo assim, ou não, determino imediata remessa do processo feito neste órgão sempre julgador  do juízo de retratação	", "criterio":"	Determino adj4 (encaminhamento ou remessa) adj4 (autos ou processo ou feito) adj4 (órgão ou turma) adj2 julgador$ adj4 juízo adj2 retratação	", "retorno":	True	},
                {"texto":"	casas de da do papel	", "criterio":"	(casas ou apartamento) adj3 (papel ou folha ou papeis)	", "retorno":	False	},
                {"texto":"	a redução do estômago foi bem sucedida	", "criterio":"	(bariatrica ou obesidade ou gastroplastia) ou (redu$ adj2 estoma$)	", "retorno":	True	},
                {"texto":"	a turma resolveu conceder um habeas corpus por meio desse oficio legal	", "criterio":"	conceder adj2 'habeas corpus' adj4 'ofício'	", "retorno":	True	},
                {"texto":"	sendo assim, ou não, determino imediato encaminhamento dos autos deste processo ao órgão sempre julgador  do juízo de retratação	", "criterio":"	Determino adj4 (encaminhamento ou remessa) adj4 (autos ou processo ou feito) adj4 (órgão ou turma) adj2 julgador$ adj4 juízo adj2 retratação	", "retorno":	True	},
                {"texto":"	confirmando que o dano moral que pode ser estético foi assumido a	", "criterio":"	'dano moral' adj5 estético não (presumido? ou presumida?)	", "retorno":	True	},
                {"texto":"	teste de texto agravo não provido ou sei lá	", "criterio":"	agravo adj5 provido nao ('nao provido')	", "retorno":	False	},
                {"texto":"	a casa de ferro é um teste	", "criterio":"	casa ADJ1 de ADJ1 ferro e teste	", "retorno":	True	},
                {"texto":"	'sendo assim, ou não, determino imediata remessa do processo feito nesta fantástica turma sempre julgadora para o juízo de retratação'	", "criterio":"	Determino adj4 (encaminhamento ou remessa) adj4 (autos ou processo ou feito) adj4 (órgão ou turma) adj2 julgador$ adj4 juízo adj2 retratação	", "retorno":	True	},
                {"texto":"	nesse contexto, indefiro a liminar entre outras coisas mais, solicito muito mais informações	", "criterio":"	indefir$ adj4 liminar (solicit$ adj5 informações)	", "retorno":	True	},
                {"texto":"	ele fez uma bariatrica esse mês	", "criterio":"	(bariatrica ou obesidade ou gastroplastia) ou (redu$ adj2 estoma$)	", "retorno":	True	},
                {"texto":"	a b c d e f	", "criterio":"	(a adj b adj c) ou (c adj d)	", "retorno":	True	},
                {"texto":"	dano  bla material	", "criterio":"	(dano ou moral) adj2 (dano ou material)	", "retorno":	True	},
                {"texto":"	o apartamento de folha e um filme interessante	", "criterio":"	(casa ou apartamento) adj3 (papel ou folha) adj3 filme	", "retorno":	True	},
                {"texto": {"a":"esse é um teste com campos", "b":"esse outro teste com campos"}, "criterio": "(teste adj2 campos) e (outro com teste)" , "retorno":	True	},
                {"texto": {"a":"esse é o primeiro texto ", "b":"esse é o segundo texto"}, "criterio": "(primeiro com segundo)" , "retorno":	False	},
                {"texto": {"a":"esse é o primeiro texto ", "b":"esse é o segundo texto"}, "criterio": "(primeir? e segun$ e tex*)" , "retorno":	True	},
                {"texto": "153.972.567. números quebrados por pontos", "criterio": "1539725$ E ('1539725'$ ou '1.539. 725'$ ou '1283540' ou '1.283.540'$)", "retorno": True},
                {"texto": " conteúdo no meio com critérios com todos os curingas", "criterio": "$ri$ri$ E ?ur?nga? ", "retorno": 1, "retorno_aon": False},
                {'texto': "palavra contendo teste", "criterio": "palavraa NAO (palavrab E palavrac com palavra e palavra nao (palavra ou palavra)) E palavraf nao teste", "retorno": False},
                {'texto': "palavraa contendo testa", "criterio": "palavraa NAO (palavrab E palavrac com palavra e palavra nao (palavra ou palavra)) E palavraf nao teste", "retorno": True},
                {'texto': ['esse é um teste simples','esse é outro teste simples'], 'criterio':'esse ADJ3 teste ADJ1 simples outro adj2 simples', 'retorno':True },
                {'texto': ['esse é um teste simples','esse é outro teste simples'], 'criterio':'esse ADJ3 teste ADJ1 simples NAO (outro adj2 simples)', 'retorno':False},
                ]

TESTES_TEXTOS = [
            {'texto':'esse é um simples teste de tokenização',
             'mapa': {'esse': {'t': [0], 'p': [0], 'c': ['']}, 'e': {'t': [1], 'p': [0], 'c': ['']}, 'um': {'t': [2], 'p': [0], 'c': ['']}, 'simples': {'t': [3], 'p': [0], 'c': ['']}, 'teste': {'t': [4], 'p': [0], 'c': ['']}, 'de': {'t': [5], 'p': [0], 'c': ['']}, 'tokenizacao': {'t': [6], 'p': [0], 'c': ['']}} 
             },
            {'texto':'fazer-se-ia um texto top-blaster, mas não deu',
             'mapa': {'fazer': {'t': [0], 'p': [0], 'c': ['']}, 'se': {'t': [1], 'p': [0], 'c': ['']}, 'ia': {'t': [2], 'p': [0], 'c': ['']}, 'um': {'t': [3], 'p': [0], 'c': ['']}, 'texto': {'t': [4], 'p': [0], 'c': ['']}, 'top': {'t': [5], 'p': [0], 'c': ['']}, 'blaster': {'t': [6], 'p': [0], 'c': ['']}, 'ma': {'t': [7], 'p': [0], 'c': ['']}, 'nao': {'t': [8], 'p': [0], 'c': ['']}, 'deu': {'t': [9], 'p': [0], 'c': ['']} } 
             },
            {'texto':'Senhor, conceda-me a serenidade para aceitar aquilo que não posso mudar, a coragem para mudar o que me for possível e a sabedoria para saber discernir entre as duas.<br>Pois assim poderei ser razoavelmente feliz nesta vida e supremamente feliz na outra.', 
             'mapa':{'senhor': {'t': [0], 'p': [0], 'c': ['']}, 'conceda': {'t': [1], 'p': [0], 'c': ['']}, 'me': {'t': [2, 18], 'p': [0, 0], 'c': ['', '']}, 'a': {'t': [3, 12, 22, 28], 'p': [0, 0, 0, 0], 'c': ['', '', '', '']}, 'serenidade': {'t': [4], 'p': [0], 'c': ['']}, 'para': {'t': [5, 14, 24], 'p': [0, 0, 0], 'c': ['', '', '']}, 'aceitar': {'t': [6], 'p': [0], 'c': ['']}, 'aquilo': {'t': [7], 'p': [0], 'c': ['']}, 'que': {'t': [8, 17], 'p': [0, 0], 'c': ['', '']}, 'nao': {'t': [9], 'p': [0], 'c': ['']}, 'posso': {'t': [10], 'p': [0], 'c': ['']}, 
             'mudar': {'t': [11, 15], 'p': [0, 0], 'c': ['', '']}, 'coragem': {'t': [13], 'p': [0], 'c': ['']}, 'o': {'t': [16], 'p': [0], 'c': ['']}, 'for': {'t': [19], 'p': [0], 'c': ['']}, 'possivel': {'t': [20], 'p': [0], 'c': ['']}, 'e': {'t': [21, 38], 'p': [0, 1], 'c': ['', '']}, 'sabedoria': {'t': [23], 'p': [0], 'c': ['']}, 'saber': {'t': [25], 'p': [0], 'c': ['']}, 'discernir': {'t': [26], 'p': [0], 'c': ['']}, 'entre': {'t': [27], 'p': [0], 'c': ['']}, 'dua': {'t': [29], 'p': [0], 'c': ['']}, 'pol': {'t': [30], 'p': [1], 'c': ['']}, 'assim': {'t': [31], 'p': [1], 'c': ['']}, 
             'poderei': {'t': [32], 'p': [1], 'c': ['']}, 'ser': {'t': [33], 'p': [1], 'c': ['']}, 'razoavelmente': {'t': [34], 'p': [1], 'c': ['']}, 'feliz': {'t': [35, 40], 'p': [1, 1], 'c': ['', '']}, 'nesta': {'t': [36], 'p': [1], 'c': ['']}, 'vida': {'t': [37], 'p': [1], 'c': ['']}, 'supremamente': {'t': [39], 'p': [1], 'c': ['']}, 'na': {'t': [41], 'p': [1], 'c': ['']}, 'outra': {'t': [42], 'p': [1], 'c': ['']}}
             },
             {'texto': 'esse é um texto<br>com mais de uma linha\ntestando vários tipos de quebras\rfinal',
              'mapa' : {'esse': {'t': [0], 'p': [0], 'c': ['']}, 'e': {'t': [1], 'p': [0], 'c': ['']}, 'um': {'t': [2], 'p': [0], 'c': ['']}, 'texto': {'t': [3], 'p': [0], 'c': ['']}, 'com': {'t': [4], 'p': [1], 'c': ['']}, 'mal': {'t': [5], 'p': [1], 'c': ['']}, 'de': {'t': [6, 12], 'p': [1, 2], 'c': ['', '']}, 
              'uma': {'t': [7], 'p': [1], 'c': ['']}, 'linha': {'t': [8], 'p': [1], 'c': ['']}, 'testando': {'t': [9], 'p': [2], 'c': ['']}, 'vario': {'t': [10], 'p': [2], 'c': ['']}, 'tipo': {'t': [11], 'p': [2], 'c': ['']}, 'quebra': {'t': [13], 'p': [2], 'c': ['']}, 'final': {'t': [14], 'p': [2], 'c': ['']}}
              }
    ]

TESTES_CRITERIOS  = [
            {"criterio": '"teste-$" "simples" teste$ simples solicite-$',
             "criterio_final": '"teste$" E "simples" E teste$ E simples E solicite$',
             "criterio_tokens": ['"', 'teste$', '"', '"', 'simples', '"', 'teste$', 'simples', 'solicite$'],
             'criterio_aon': 'teste* AND "simples" AND teste* AND simples AND solicite*',
            },
            {"criterio": "'teste' 'testa'",
             "criterio_final": '"teste" E "testa"',
             "criterio_tokens": ['"','teste','"','"','testa','"'],
             'criterio_aon': '"teste" AND "testa"',
            },
            {'criterio': "palavra E palavra COM palavra OU palavra NAO (palavra)",
             'criterio_tokens': ['palavra', 'e', 'palavra', 'com', 'palavra', 'ou', 'palavra', 'nao', '(', 'palavra', ')'],
             'criterio_aon': '( palavra AND palavra AND palavra ) OR palavra NOT ( palavra )',
             },
            {'criterio': '(NÃO casa) (Não nada) (não "tudo") (nao "não")',
             'criterio_tokens': ['(', 'nao', 'casa', ')', '(', 'nao', 'nada', ')', '(', 'nao', '(', '"', 'tudo', '"', ')', '(', 'nao', '"', 'nao', '"', ')', ')'],
             'criterio_aon': '( NOT casa ) AND ( NOT nada ) AND ( NOT ( "tudo" ) AND ( NOT "nao" ) )',
             },
            {'criterio': "palavraa NAO (palavrab E palavrac)",
             'criterio_tokens': ['palavraa', 'nao', '(', 'palavrab', 'e', 'palavrac',')'],
             'criterio_aon': 'palavraa NOT ( palavrab AND palavrac )',
             },
            {'criterio': "palavraa NAO (palavrab ADJ1 palavrac)",
             'criterio_tokens': ['palavraa', 'nao', '(', 'palavrab', 'adj1', 'palavrac',')'],
             'criterio_aon': 'palavraa',
             },
            {'criterio': "palavraa NAO (palavrab E palavrac com palavra e palavra nao (palavra ou palavra)) E palavraf nao teste",
             'criterio_tokens': ['palavraa', 'nao', '(', 'palavrab', 'e', 'palavrac', 'com', 'palavra', 'e', 'palavra', 'nao', '(', 'palavra', 'ou', 'palavra', ')', ')', 'e', 'palavraf', 'nao', 'teste'],
             'criterio_aon': 'palavraa NOT teste',
             },
            {"criterio": "contra$ 'recurso extra$' proxc5 apresentado",
             "criterio_final": 'contra$ E "recurso extra$" PROXC5 apresentado',
             "criterio_tokens": ['contra$', '"', 'recurso', 'extra$', '"', 'proxc5', 'apresentado'],
             'criterio_aon': 'contra* AND "recurso extra*" AND apresentado',
            },
            {"criterio": "contra$ 'recurso extra$' outro proxc5 apresentado",
             "criterio_final": 'contra$ E "recurso extra$" E outro PROXC5 apresentado',
             "criterio_tokens": ['contra$', '"', 'recurso', 'extra$', '"', 'outro', 'proxc5', 'apresentado'],
             'criterio_aon': 'contra* AND "recurso extra*" AND outro AND apresentado',
            },
            {"criterio": "contra$ ('recurso extra$' outro) proxc5 apresentado",
             "criterio_final": 'contra$ E ( "recurso extra$" E outro ) PROXC5 apresentado',
             "criterio_tokens": ['contra$', '(', '"', 'recurso', 'extra$', '"', 'outro', ')', 'proxc5', 'apresentado'],
             'criterio_aon': 'contra* AND ( "recurso extra*" AND outro ) AND apresentado',
            },
            {"criterio": "contra$ ('recurso extra$' outro 'recurso extra') nada tudo proxc5 apresentado",
             "criterio_final": 'contra$ E ( "recurso extra$" E outro E "recurso extra" ) E nada E tudo PROXC5 apresentado',
             "criterio_tokens": ['contra$', '(', '"', 'recurso', 'extra$', '"', 'outro', '"', 'recurso', 'extra', '"', ')', 'nada', 'tudo', 'proxc5', 'apresentado'],
             'criterio_aon': 'contra* AND ( "recurso extra*" AND outro AND "recurso extra" ) AND nada AND tudo AND apresentado',
            },
            {"criterio": "teste NÃO palavras NÃO textos",
             "criterio_final": 'teste NAO palavra NAO texto',
             "criterio_tokens": ['teste','nao','palavra','nao','texto'],
             'criterio_aon': 'teste NOT palavra NOT texto',
            },
    ]

TESTES_GRIFAR = [
            {'texto': 'teste com vários textos iguais que devem ser iguais na marcação do teste',
             'criterio': 'testes teste texto igual',
             'texto_processado': 'teste com vario~ texto~ igual~ que devem ser igual~ na marcacao do teste',
             'texto_grifado' : '<mark>teste</mark> com vários <mark>textos</mark> <mark>iguais</mark> que devem ser <mark>iguais</mark> na marcação do <mark>teste</mark>'
             },
            {'texto': 'teste com \nvários textos iguais \nque devem ser \niguais\n\n\n na marcação do teste',
             'criterio': 'testes teste texto igual',
             'texto_processado': 'teste com <br>vario~ texto~ igual~ <br>que devem ser <br>iguais<br><br><br> na marcacao do teste',
             'texto_grifado' : '<mark>teste</mark> com \nvários <mark>textos</mark> <mark>iguais</mark> \nque devem ser \niguais\n\n\n na marcação do <mark>teste</mark>'
             },
            {'texto': ' "A Casa de Papel" R$ 1.234,33 legais. <br> Um bla-ble-bli outros textos § 5, é muito legal alegre e feliz!',
             'criterio': '"casa de papel" E lega$ E alegr? E 123433',
             'texto_processado': '  a casa de papel  r  1_234_33 legais  <br> um bla ble bli outro~ texto~ § 5  e muito legal alegre e feliz ',
             'texto_grifado' : ' "A <mark>Casa de Papel</mark>" R$ <mark>1.234,33</mark> <mark>legais</mark>. <br> Um bla-ble-bli outros textos § 5, é muito <mark>legal</mark> <mark>alegre</mark> e feliz!'
             },
             {'texto' : 'Uma unidade custa R$ 1123,57. Duas unidades sai com desconto por R$ 2240,73 e na Black friday cada unidade sai por apenas R$ 130,00. Isso no dia 01/02/2003',
              'criterio' : "'01/02/2003' 1.123,57",
              'texto_processado':'uma unidade custa r  1123_57  dua~ unidade~ sai com desconto por r  2240_73 e na black friday cada unidade sai por apena~ r  130_00  isso no dia 01 02 2003',
              'texto_grifado':'Uma unidade custa R$ <mark>1123,57</mark>. Duas unidades sai com desconto por R$ 2240,73 e na Black friday cada unidade sai por apenas R$ 130,00. Isso no dia <mark>01/02/2003</mark>'
             },
             {'texto' : 'esse voto e vista texto tem voto-vista nele ácéntó barra/barra',
              'criterio' : "'voto-vista' ácéntó barra",
              'texto_processado':'esse voto e vista texto tem voto vista nele acento barra barra',
              'texto_grifado':'esse voto e vista texto tem <mark>voto-vista</mark> nele <mark>ácéntó</mark> <mark>barra</mark>/<mark>barra</mark>'
             },
             {'texto' : 'esse voto e vista texto tem voto-vista nele ácéntó barra/barra',
              'criterio' : "voto-vista ácéntó barra",
              'texto_processado':'esse voto e vista texto tem voto vista nele acento barra barra',
              'texto_grifado':'esse <mark>voto</mark> e <mark>vista</mark> texto tem <mark>voto</mark>-<mark>vista</mark> nele <mark>ácéntó</mark> <mark>barra</mark>/<mark>barra</mark>'
             },
             {'texto' : 'teste de e-mail',
              'criterio' : "'e' mail",
              'texto_processado':'teste de e mail',
              'texto_grifado':'teste de <mark>e</mark>-<mark>mail</mark>'
             },
             {'texto' : 'teste de e-mail',
              'criterio' : "r:e-mail",
              'texto_processado':'teste de e-mail',
              'texto_grifado':'teste de <mark>e-mail</mark>'
             },
             {'texto' : 'teste de e-mail com outro texto interessante',
              'criterio' : "r:e-mail|texto",
              'texto_processado':'teste de e-mail com outro texto interessante',
              'texto_grifado':'teste de <mark>e-mail</mark> com outro <mark>texto</mark> interessante'
             }                  
]            

TESTES_EXTRACAO = [
    {'texto': "a casa de papel é um seriado bem interessante numero123\nsegundo texto da casa sem papel",
     'criterio' : "r:casa.{1,20}papel", 
     'esperado' : {'retorno': True, 
                   'extracao': [{'inicio': 2, 'fim': 15, 'texto': 'casa de papel'}, 
                                {'inicio': 73, 'fim': 87, 'texto': 'casa sem papel'}], 
                   'texto_grifado': 'a <mark>casa de papel</mark> e um seriado bem interessante numero123\nsegundo texto da <mark>casa sem papel</mark>', 
                   'criterios': 'casa.{1,20}papel', 
                   'texto': 'a casa de papel e um seriado bem interessante numero123\nsegundo texto da casa sem papel', 
                   'criterios_analise': 'r:casa.{1,20}papel'}
    },
    {'texto': {"a": "a casa de papel é um seriado bem interessante numero123", "b": "segundo texto da casa sem papel"},
     'criterio' : "r:casa.{1,20}papel", 
     'esperado' : {'retorno': True, 
                   'extracao': [{'inicio': 2, 'fim': 15, 'texto': 'casa de papel', 'chave': 'a'}, 
                                {'inicio': 17, 'fim': 31, 'texto': 'casa sem papel', 'chave': 'b'}], 
                   'criterios': 'casa.{1,20}papel', 
                   'texto': {'a': 'a casa de papel e um seriado bem interessante numero123', 
                             'b': 'segundo texto da casa sem papel'}, 
                   'criterios_analise': 'r:casa.{1,20}papel',
                   'texto_grifado': {'a': 'a <mark>casa de papel</mark> e um seriado bem interessante numero123',
                                     'b': 'segundo texto da <mark>casa sem papel</mark>'}
                  }
    },
    {'texto': ["a casa de papel é um seriado bem interessante numero123", "segundo texto da casa sem papel"],
     'criterio' : "r:casa.{1,20}papel", 
     'esperado' : {'retorno': True, 
                   'extracao': [{'inicio': 2, 'fim': 15, 'texto': 'casa de papel', 'pagina': 1}, 
                                {'inicio': 17, 'fim': 31, 'texto': 'casa sem papel', 'pagina': 2}], 
                   'criterios': 'casa.{1,20}papel', 
                   'texto': ['a casa de papel e um seriado bem interessante numero123', 'segundo texto da casa sem papel'],
                   'texto_grifado': ['a <mark>casa de papel</mark> e um seriado bem interessante numero123',
                                     'segundo texto da <mark>casa sem papel</mark>'],
                   'criterios_analise': 'r:casa.{1,20}papel'}
    }
]

TESTES_RETORNO_COMPLETO = [
  {"texto" : "esse teste é simples 123,45 123.123 simples",
   "criterio" : "esse teste simples",
   "esperado" : {"criterios": "esse E teste E simples",
                        "criterios_analise": "esse teste simples",
                        "criterios_aon": "esse AND teste AND simples",
                        "retorno": True,
                        "texto": "esse teste e simples 12345 123123 simples",
                        "texto_grifado": "<mark>esse</mark> <mark>teste</mark> é <mark>simples</mark> 123,45 123.123 <mark>simples</mark>"
                        } },
  {"texto" : "esse teste é simples 123,45 123.123 simples",
   "criterio" : "r:(esse)|(teste)|(simples)",
   "esperado" : { "criterios":"(esse)|(teste)|(simples)",
                         "criterios_analise":"r:(esse)|(teste)|(simples)",
                         "extracao":[{"fim":4,"inicio":0,"texto":"esse"},{"fim":10,"inicio":5,"texto":"teste"},{"fim":20,"inicio":13,"texto":"simples"},{"fim":43,"inicio":36,"texto":"simples"}],   
                         "retorno": True,
                         "texto": "esse teste e simples 123,45 123.123 simples",
                         "texto_grifado": "<mark>esse</mark> <mark>teste</mark> e <mark>simples</mark> 123,45 123.123 <mark>simples</mark>"
                       }},
  {'texto': ["primeiro da lista", "segundo da lista"],
   'criterio' : "primeiro adj2 lista segundo adj2 lista", 
   'esperado' : {'retorno': True, 
                   'criterios': 'primeiro ADJ2 lista E segundo ADJ2 lista', 
                   'criterios_aon': 'primeiro AND lista AND segundo AND lista',
                   'texto': ["primeiro da lista", "segundo da lista"], 
                   'criterios_analise': 'primeiro adj2 lista segundo adj2 lista',
                   'texto_grifado': ["<mark>primeiro</mark> da <mark>lista</mark>", 
                                     "<mark>segundo</mark> da <mark>lista</mark>"]
                  }
    },
  {'texto': ["primeiro da lista", "segundo da lista"],
   'criterio' : "primeiro adj2 lista com segundo", 
   'esperado' : {'retorno': False, 
                   'criterios': 'primeiro ADJ2 lista COM1 segundo', 
                   'criterios_aon': 'primeiro AND lista AND segundo',
                   'texto': ["primeiro da lista", "segundo da lista"], 
                   'criterios_analise': 'primeiro adj2 lista com segundo',
                   'texto_grifado': ['<mark>primeiro</mark> da <mark>lista</mark>',
                                     '<mark>segundo</mark> da <mark>lista</mark>']
                  }
    }
]

TESTES_CABECALHO_RODAPE = [
    {"texto": "teste de texto com recortes de cabecalho e rodape", 
     "regras_externas" : [
    {"grupo" : "grupo", "rotulo": "teste1", "regra": "rodape cabecalho nao teste nao texto", "qtd_cabecalho":0, "qtd_rodape":22},
    {"grupo" : "grupo", "rotulo": "teste2", "regra": "teste texto nao cabecalho nao rodape", "qtd_cabecalho":27, "qtd_rodape":0},
    {"grupo" : "grupo", "rotulo": "teste3", "regra": "teste rodape nao texto nao cabecalho", "qtd_cabecalho":10, "qtd_rodape":10},
    {"grupo" : "grupo", "rotulo": "teste4", "regra": "teste texto recortes cabecalho rodape", "qtd_cabecalho":0, "qtd_rodape":0},
    {"grupo" : "grupo", "rotulo": "teste5", "regra": "teste texto recortes cabecalho rodape", "qtd_cabecalho":50, "qtd_rodape":50}
    ],
    'esperado' : ['teste1', 'teste2', 'teste3', 'teste4', 'teste5'],
    'textos' : [' de cabecalho e rodape', 'teste de texto com recortes', 'teste de t o e rodape', 'teste de texto com recortes de cabecalho e rodape', 'teste de texto com recortes de cabecalho e rodape']
    },
    {"texto": "teste de texto 'trecho aspas' aaa bbb com recortes de cabecalho e rodape", 
     "regras_externas" : [
    {"grupo" : "grupo", "rotulo": "teste1", "regra": "rodape cabecalho nao teste nao texto nao aspas nao aaa nao bbb remover(aspas) remover(aaa) remover(bbb)", "qtd_cabecalho":0, "qtd_rodape":22},
    {"grupo" : "grupo", "rotulo": "teste2", "regra": "teste texto nao cabecalho nao rodape nao aspas nao aaa nao bbb  remover(aspas) remover(aaa) remover(bbb)", "qtd_cabecalho":27, "qtd_rodape":0},
    {"grupo" : "grupo", "rotulo": "teste3", "regra": "teste rodape nao texto nao cabecalho nao aspas nao aaa nao bbb  remover(aspas) remover(aaa) remover(bbb)", "qtd_cabecalho":10, "qtd_rodape":10},
    {"grupo" : "grupo", "rotulo": "teste4", "regra": "teste texto recortes cabecalho rodape nao aspas nao aaa nao bbb  remover(aspas) remover(aaa) remover(bbb)", "qtd_cabecalho":0, "qtd_rodape":0},
    {"grupo" : "grupo", "rotulo": "teste5", "regra": "teste texto recortes cabecalho rodape nao aspas nao aaa nao bbb  remover(aspas) remover(aaa) remover(bbb)", "qtd_cabecalho":50, "qtd_rodape":50}
    ],
    'esperado' : ['teste1', 'teste2', 'teste3', 'teste4', 'teste5'],
    'textos' : ['de cabecalho e rodape', 'teste de texto       co', 'teste de t o e rodape', 'teste de texto       com recortes de cabecalho e rodape', 'teste de texto       com recortes de cabecalho e rodape']
    },
    {"texto": "teste de texto 'trecho aspas' aaa bbb com recortes de cabecalho e rodape", 
     "regras_externas" : [
    {"grupo" : "grupo", "rotulo": "teste1", "regra": "r:cabecalho.*rodape remover(aspas) remover(aaa) remover(bbb)", "qtd_cabecalho":0, "qtd_rodape":22},
    {"grupo" : "grupo", "rotulo": "teste1_nao", "regra": "r:aaa|bbb|ccc|teste|texto", "qtd_cabecalho":0, "qtd_rodape":22},
    {"grupo" : "grupo", "rotulo": "teste2", "regra": "r:teste.*texto remover(aspas) remover(aaa) remover(bbb)", "qtd_cabecalho":27, "qtd_rodape":0},
    {"grupo" : "grupo", "rotulo": "teste2_nao", "regra": "r:aspas|aaa|bbb|com|recortes|cabecalho|rodape remover(aspas) remover(aaa) remover(bbb)", "qtd_cabecalho":27, "qtd_rodape":0},
    {"grupo" : "grupo", "rotulo": "teste3", "regra": "r:teste rodape", "qtd_cabecalho":5, "qtd_rodape":6},
    {"grupo" : "grupo", "rotulo": "teste3_nao", "regra": "r:aaa|bbb|de|cabecalho", "qtd_cabecalho":5, "qtd_rodape":6},
    {"grupo" : "grupo", "rotulo": "teste4", "regra": "r:teste.*rodape remover(aspas) remover(aaa) remover(bbb)", "qtd_cabecalho":0, "qtd_rodape":0},
    {"grupo" : "grupo", "rotulo": "teste4_nao", "regra": "r:teste.*bbb.*rodape remover(aspas) remover(aaa) remover(bbb)", "qtd_cabecalho":0, "qtd_rodape":0},
    {"grupo" : "grupo", "rotulo": "teste5", "regra": "r:teste.*rodape remover(aspas) remover(aaa) remover(bbb)", "qtd_cabecalho":50, "qtd_rodape":50},
    {"grupo" : "grupo", "rotulo": "teste5_nao", "regra": "r:teste.*bbb.*rodape remover(aspas) remover(aaa) remover(bbb)", "qtd_cabecalho":50, "qtd_rodape":50},
    ],
    'esperado' : ['teste1', 'teste2', 'teste3', 'teste4', 'teste5'],
    'textos' : ['de cabecalho e rodape', 'teste de texto       co', 'teste rodape', 'teste de texto       com recortes de cabecalho e rodape', 'teste de texto       com recortes de cabecalho e rodape']
    }
]
