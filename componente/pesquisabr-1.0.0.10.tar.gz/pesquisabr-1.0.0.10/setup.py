import setuptools
#
# Para gerar o dist, executar: 
#   python setup.py sdist 

setuptools.setup(
    name="pesquisabr",
    version= '1.0.0.10',
    author="Luiz Anísio",
    author_email="",
    description="Projeto para pesquisa textual",
    long_description='Pacote base para os projetos com pesquisa textual avançada',
    long_description_content_type="text/markdown",
    url="https://github.com/luizanisio/PesquisaTextualBR",
    packages = setuptools.find_packages(),
    package_data={'':['*.md','LICENCE','*.py','*.sql'],},
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: MIT License",
        "Operating System :: OS Independent",
    ],
)

### NOTAS DE VERSÕES 
''' 
 1.0.0.5  - singularização aprimorada com lista de palavras ignoradas no falso plural
          - melhoria dos testes para as singularizações
 1.0.0.6  - correção do ADJC (erro inserido em algum teste anterior ou refactoring)
          - melhoria dos testes para o ADJC
 1.0.0.7  - reorganização e melhoria na construção do pacote pesquisabr e submódulos
          - pode-se usar:
            - from pesquisabr import PesquisaBR, RegrasPesquisaBR
            - from pesquisabr import PesquisaBRTestes
 1.0.0.8  - testes com mapas de tokenização, preparando para a primeira versão de homologação
 1.0.0.9  - testes com operador COM 1,2 e 3
          - correção de termo único entre aspas na criação do critério AON
 1.0.0.10 - não (critério especial) para AON deve ser TRUE
          - teste não (palavra1 ADJC palavra2)  ==> teste 
          - not com operadores especiais não tem como ser avaliado no AON, então o maior filtro possível é
            retirar o grupo do NOT para que o AON retorne os dados para serem filtrados pelo python depois
 '''