import unittest
import re 
from pesquisabr import PesquisaBR, RegrasPesquisaBR

class PesquisaBRTestes():
    @staticmethod
    def testes_completos():
        for t in TESTES_COMPLETOS:
            yield t

    @staticmethod
    def testes_basicos():
        for t in TESTES_BASICOS:
            yield t

    @staticmethod
    def testes_texto():
        for t in TESTES_TEXTOS:
            yield t

class TestPesquisaBR(unittest.TestCase):

    def teste(self):
        self.assertTrue(len(TESTES_COMPLETOS)>0)
        self.assertTrue(len(TESTES_TEXTOS)>0)
        self.assertTrue(len(__texto__)>0)

    def teste_tokenizacao(self):
        for i, t in enumerate(TESTES_TEXTOS):
            pb = PesquisaBR(texto=t['texto'])
            mapa = pb.mapa_texto
            with self.subTest(f'tokenização - mapa final {i}/{len(TESTES_TEXTOS)}'):
                print(f'Teste de Mapa: {i}/{len(TESTES_TEXTOS)}', mapa)
                self.assertDictEqual(t['mapa'],mapa)

    def teste_tokenizacao_criterios(self):
        for i, t in enumerate(TESTES_CRITERIOS):
            with self.subTest(f'tokenização - critério {i}/{len(TESTES_CRITERIOS)}'):
                pb = PesquisaBR(criterios = str(t['criterio']))
                print(f'Critério {i}/{len(TESTES_CRITERIOS)}: ', str(t['criterio']))
                print(f'Critério tokenizado: ', pb.tokens_criterios)
                print(f'Critério    : ', pb.criterios)
                print(f'Critério AON: ', pb.criterios_and_or_not)
                self.assertCountEqual(t['criterio_tokens'],pb.tokens_criterios)
                self.assertEqual(t['criterio_aon'],pb.criterios_and_or_not)

    ###########################################################
    ## básicos - tokens, critérios, etc
    def teste_criterios_tokens(self):
        _criterios = 'esse teste simples'
        _texto = 'esse é um teste simples repetindo teste simples'
        pb = PesquisaBR(texto=_texto, criterios=_criterios, print_debug=False)
        if not pb.retorno():
            self.print_erro('TEXTO EM DICIONÁRIO - esperado False')
            pb.print_resumo()
        self.assertEqual(pb.retorno(), True)
        # verifica os tokens
        tokens_esperados = ['esse','e','um','teste','simples','repetindo','teste','simples']
        self.assertCountEqual(pb.tokens_texto, tokens_esperados)
        # verifica os tokens únicos
        tokens_esperados = ['esse','e','um','teste','simples','repetindo']
        self.assertCountEqual(pb.tokens_texto_unicos, tokens_esperados)
        # verifica crit[erios]
        self.assertEqual(pb.criterios, 'esse E teste E simples')
        # verifica AON
        self.assertEqual(pb.criterios_and_or_not, 'esse AND teste AND simples')
        # verifica o mapa
        mapa_texto = {'e': {'c': [''], 'p': [0], 't': [1]},
                      'esse': {'c': [''], 'p': [0], 't': [0]},
                      'repetindo': {'c': [''], 'p': [0], 't': [5]},
                      'simples': {'c': ['', ''], 'p': [0, 0], 't': [4, 7]},
                      'teste': {'c': ['', ''], 'p': [0, 0], 't': [3, 6]},
                      'um': {'c': [''], 'p': [0], 't': [2]}}
        self.assertDictEqual(pb.mapa_texto, mapa_texto)
        # singulares
        _texto = 'casas tres simples abbtas thrs ghdls wcasas ycasas as es is os us '
        _texto += ' ' + ' '.join(PesquisaBR.LST_SINGULAR_IGNORAR)
        pb = PesquisaBR(texto=_texto, criterios='', print_debug=False)
        tokens_esperados = ['casa','simples','tres','abbtas','ghdls','thrs','wcasas','ycasas','a','e','il','o','u']
        tokens_esperados += PesquisaBR.LST_SINGULAR_IGNORAR
        self.assertCountEqual(pb.tokens_texto_unicos, list(set(tokens_esperados)))

    ###########################################################
    ## básicos - tokens, critérios, etc
    def teste_sinonimos(self):
        _criterios = 'ele adj3 alegre'
        _texto = 'ele está muito feliz'
        pb = PesquisaBR(texto=_texto, criterios=_criterios, print_debug=False)
        if not pb.retorno():
            self.print_erro('SINÔNIMOS - esperado True')
            pb.print_resumo()
        self.assertEqual(pb.retorno(), True)

        # desativa o dicionário e testa novamente
        pb = PesquisaBR(texto='', criterios=_criterios, print_debug=False)
        pb.SINONIMOS = {}
        pb.novo_texto(_texto,atualizar_pesquisa=True)
        if pb.retorno():
            self.print_erro('SINÔNIMOS - esperado False')
            pb.print_resumo()
        self.assertEqual(pb.retorno(), False)

        pb = PesquisaBR(texto=_texto, criterios=_criterios, print_debug=False)
        # verifica o mapa
        mapa_texto = {'ele': {'t': [0], 'p': [0], 'c': ['']}, 
                      'esta': {'t': [1], 'p': [0], 'c': ['']}, 
                      'muito': {'t': [2], 'p': [0], 'c': ['']}, 
                      'feliz': {'t': [3], 'p': [0], 'c': ['']}}
        print(pb.mapa_texto)              
        self.assertDictEqual(pb.mapa_texto, mapa_texto)

    def teste_texto_dicionario_1(self):
        _criterios = 'texto com civil não aqui'
        _texto = {'texto':'texto aqui responsabilidade civil do estado','numero':123}
        pb = PesquisaBR(texto=_texto, criterios=_criterios, print_debug=False)
        if pb.retorno():
            self.print_erro('TEXTO EM DICIONÁRIO - esperado False')
            pb.print_resumo()
        self.assertEqual(pb.retorno(), False)

    def teste_texto_dicionario_2(self):
        _criterios = '((purgação adj2 mora) com ((integr$ ou tota$) com dívida ou débito ou pagamento) ou débito) e ((busca adj2 apreensao) ou 911/??69)'
        _texto = {'texto':'texto aleatório para passar - purgação de mora por ocorrer na integração de uma dívida no débito para ocorrer busca e apreensao','numero':123}
        pb = PesquisaBR(texto=_texto, criterios=_criterios, print_debug=False)
        if not pb.retorno():
            self.print_erro('TEXTO EM DICIONÁRIO - esperado True')
            pb.print_resumo()
        self.assertEqual(pb.retorno(), True)

    ################################################################################
    # realiza testes internos e pode receber testes complementares
    # se um teste falhar, ativa o debug e realiza novamente o teste
    # para apresentar facilitar a análise - interrompe os testes ao falhar um deles
    ################################################################################
    def testes_completos(self,testes=None, somar_internos=True):
        # {"texto" : "", "criterio":, "resposta" : true/false}

        # remover o próximo comentário para testar falha do teste
        # TESTES_COMPLETOS[0]['retorno'] =False

        """
        Teste com as principais regras e combinações conhecidas
        """
        falha = ''
        pb=PesquisaBR()
        _testes = []
        if (testes is None) or (somar_internos):
            _testes = TESTES_COMPLETOS
        fim_internos = len(_testes) if not (_testes is None) else -1
        if not (testes is None):
            _testes += testes
        pb.print_debug = False
        for i, teste in enumerate(_testes):
            if i == fim_internos :
                print('---------------------------------------')
                print('------  FIM DOS TESTES INTERNOS -------')
            texto = teste['texto']
            criterio = str(teste['criterio'])
            print('CRITERIO RECEBIDO: ', criterio)
            print('---------------------------------------')
            print(f'Teste: {i} - {criterio}  ==> esperado {teste["retorno"]}')
            pb.novo_texto(texto)
            pb.novo_criterio(criterio)
            if teste["retorno"]:
                print(f'   AON => {pb.criterios_and_or_not}')
            retorno = None
            if pb.erros =='':
                retorno = pb.analisar_mapa_pesquisa()
            if pb.erros!= '' or retorno != teste['retorno']:
                if pb.erros != '':
                    falha = f'ERRO NOS CRITÉRIOS: {pb.erros}'
                    self.print_erro(falha)
                else:
                    falha = f'ERRO NO RETORNO ESPERADO: {retorno} != {teste["retorno"]}'
                    self.print_erro(falha)
                pb.print_debug = True
                pb.print()
                pb.analisar_mapa_pesquisa()
                break
            # verifica a reconstrução da pesquisa apenas pelo mapa 
            # o resultado tem que ser o mesmo ao criar o mapa em tempo de execução
            pbmapa = PesquisaBR(criterios=pb.criterios, mapa_texto = pb.mapa_texto)            
            retorno = pbmapa.analisar_mapa_pesquisa() if pbmapa.erros == '' else None
            if pbmapa.erros!= '' or retorno != teste['retorno']:
                falha = 'ERRO AO REFAZAR A PESQUISA PELO MAPA'
                self.print_erro(falha)
                print(f' - Teste: {i} - {criterio}  ==> esperado {teste["retorno"]}')
                if pbmapa.erros != '':
                    print(' -- ERRO NOS CRITÉRIOS: ', pbmapa.erros)
                pbmapa.print_debug = True
                pbmapa.print()
                pbmapa.analisar_mapa_pesquisa()
                break
            # verifica o clone dos critérios
            # o resultado tem que ser o mesmo
            pbclone = pb.clone_criterios()
            pbclone.novo_mapa_texto(mapa_texto=pb.mapa_texto)
            retorno = pbclone.retorno() if pbclone.erros == '' else None
            if pbclone.erros!= '' or retorno != teste['retorno']:
                falha = 'ERRO AO REFAZER A PESQUISA PELO CLONE'
                self.print_erro(falha)
                print(f' - Teste: {i} - {criterio}  ==> esperado {teste["retorno"]}')
                if pbclone.erros != '':
                    print(' -- ERRO NOS CRITÉRIOS DO CLONE: ', pbmapa.erros)
                pbclone.print_debug = True
                pbclone.print()
                pbclone.analisar_mapa_pesquisa()
                break

            # verifica o AND OR NOT
            # convertendo a pesquisa em AND OR NOT, caso a pesquisa toda retorne TRUE, o 
            # critério AND OR NOT tem que retornar TRUE também
            # AND OR NOT é usado para acelerar a pesquisa em bancos textuais como o MemSQL/SingleStore
            criterio_aon = re.sub(' AND ',' E ', str(pb.criterios_and_or_not))
            criterio_aon = re.sub(' OR ',' OU ', criterio_aon)
            criterio_aon = re.sub(' NOT ',' NAO ', criterio_aon)
            _retorno_aon = teste.get('retorno_aon',teste["retorno"])
            if criterio_aon.strip() !='':
                if _retorno_aon==1 or _retorno_aon == True:
                    pb.novo_criterio(criterio_aon)
                    if pb.erros =='':
                        retorno = pb.analisar_mapa_pesquisa()
                    if pb.erros != '' or not retorno:
                        falha = 'CRITÉRIO AND OR NOT - FALHA ESPERADO TRUE ***'
                        print(falha)
                        if pb.erros != '':
                            print('ERRO NOS CRITÉRIOS: ', pb.erros)
                        pb.print_debug = True
                        pb.print()
                        pb.analisar_mapa_pesquisa()
                        break
            else:
                print(f'   AON => VAZIO *** ')

        self.print_erro(falha)
        self.assertEqual(len(falha)==0, True)

    ###########################################################
    ## REGRAS
    REGRAS_TESTES = [{'grupo' : 'receitas_bolo', 'rotulo': 'Receita de Bolo', 'regra': 'receita ADJ10 bolo'},
                {'grupo' : 'receitas_bolo', 'rotulo': 'Receita de Bolo', 'regra': 'aprenda ADJ5 fazer ADJ10 bolo'},
                {'grupo' : 'receitas_pao', 'rotulo': 'Receita de Pão', 'regra': 'receita PROX15 pao'},
                {'grupo' : 'grupo teste', 'rotulo': 'teste', 'regra': 'teste'}]
    def teste_regras_1(self):
        regras = self.REGRAS_TESTES
        # receita de bolo
        texto = 'nessa receita você vai aprender a fazer bolos incríveis'
        pbr = RegrasPesquisaBR(regras = regras, print_debug=False)
        rotulos = pbr.aplicar_regras(texto = texto)
        print(f'Rótulos encontrados para o texto: "{texto}" >> ', rotulos)
        self.assertCountEqual(rotulos['rotulos'], ['Receita de Bolo'])
        # receita de pão
        texto = 'pão de ló, uma receita incrível'
        pbr = RegrasPesquisaBR(regras = regras, print_debug=False)
        rotulos = pbr.aplicar_regras(texto = texto)
        print(f'Rótulos encontrados para o texto: "{texto}" >> ', rotulos)
        self.assertCountEqual(rotulos['rotulos'], ['Receita de Pão'])
        # receita de pão e bolo
        texto = 'pão de ló, uma receita incrível para uma nova forma de fazer um bolo'
        pbr = RegrasPesquisaBR(regras = regras, print_debug=False)
        rotulos = pbr.aplicar_regras(texto = texto)
        print(f'Rótulos encontrados para o texto: "{texto}" >> ', rotulos)
        self.assertCountEqual(rotulos['rotulos'], ['Receita de Pão', 'Receita de Bolo'])

    def teste_regras_2(self):
        falha = ''
        __teste_regras__ = [{'grupo' : 'grupo 1', 'rotulo': 'ok1', 'regra': 'casa ADJ2 papel'},
                            {'grupo' : 'grupo 1', 'rotulo': 'ok1', 'regra': 'seriado ADJ2 "la casa de papel"'},
                            {'grupo' : 'grupo 2', 'rotulo': 'ok2', 'regra': '"a casa de papel"'},
                            {'grupo' : 'grupo teste', 'rotulo': 'teste', 'regra': 'teste'}
                            ]
        __teste_regras_2__ = [{'grupo' : 'grupo cabecalho', 'rotulo': 'cabecalho', 'regra': 'texto', 'qtd_cabecalho':10},
                                {'grupo' : 'grupo rodape', 'rotulo': 'rodape', 'regra': 'rodapé', 'qtd_rodape':10},
                                {'grupo' : 'grupo cab rodap', 'rotulo': 'cabrodap', 'regra': 'texto E teste','qtd_cabecalho':10, 'qtd_rodape':23},
                                {'grupo' : 'grupo n cab rodap', 'rotulo': 'ncabrodap', 'regra': 'NÃO cabecalho','qtd_cabecalho':20, 'qtd_rodape':20}
                            ]
        __texto_teste__ = 'o seriado a casa de papel é legal'
        __texto_teste_2__ = 'texto com teste depois do cabecalho e teste antes do rodapé'
        #
        _obj_teste = RegrasPesquisaBR(regras = __teste_regras__, print_debug=False)
        resdic = _obj_teste.aplicar_regras(__texto_teste__)
        self.assertCountEqual(resdic['rotulos'], ['ok1','ok2'])
        # incluindo teste na pesquisa
        resdic = _obj_teste.aplicar_regras(__texto_teste__ + ' com esse teste')
        self.assertCountEqual(resdic['rotulos'], ['ok1','ok2','teste'])
        # texto sem regras aplicáveis
        resdic = _obj_teste.aplicar_regras('esse é um texto qualquer com a casa mas não tem nada de papel')
        self.assertCountEqual(resdic['rotulos'], [])
        # testes de cabeçalho e rodapé 
        _obj_teste = RegrasPesquisaBR(regras = __teste_regras_2__, print_debug=False)
        resdic = _obj_teste.aplicar_regras(__texto_teste_2__)
        self.assertCountEqual(resdic['rotulos'], ['cabrodap','cabecalho','ncabrodap','rodape'])

    def print_erro(self, msg_erro):
        if not msg_erro:
            return
        print( '###########################################################################')
        print( '########## ')
        print(f'########## {msg_erro}')
        print( '########## ')
        print( '###########################################################################')


__texto__ = "a casa de papel é um seriado bem interessante numero123"
TESTES_BASICOS = [
            {'texto':'essa teste simples','criterio':'(esse OU essa OU nada) ADJC teste PROXC simples','retorno':True},
            {'texto':'esse teste simples','criterio':'("teste simples") ("esse teste") ("esse teste simples")','retorno':True},
            {'texto':'esse essa \n teste \n simples','criterio':'(esse OU essa) teste simples','retorno':True},
            {'texto':'essa \n teste \n simples','criterio':'(esse OU essa) ADJ teste ADJ simples','retorno':True},
            {'texto':'outro \n teste \n simples','criterio':'(esse OU esso OU outro OU outra OU essa) ADJ teste ADJ simples','retorno':True},
            {'texto':'outro \n teste \n simples','criterio':'(esse OU esso OU outro OU outra OU essa) ADJC teste ADJ simples','retorno':False},
            {'texto':'outro <br> teste <br> simples','criterio':'outro COM teste','retorno':False},
            {'texto':'outro \n teste \n simples','criterio':'outro COM simples','retorno':False},
            {'texto':'outro <br> teste \n simples','criterio':'outro COM2 teste','retorno':True},
            {'texto':'outro \n teste \n simples','criterio':'outro COM2 simples','retorno':False},
            {'texto':'outro \n teste <br> simples','criterio':'outro COM3 simples','retorno':True},
            {'texto':'outro \n teste <br> simples','criterio':'(outro prox2 simples) e (simples prox2 outro) e (simples prox1 teste)','retorno':True},
            {'texto':'outro \n teste <br> simples','criterio':'(outro proxc2 simples) OU (simples proxc2 outro) OU (simples proxc1 teste)','retorno':False},
            {'texto':'outro \n teste <br> simples','criterio':'(outro adj2 simples) e (outro adj1 teste) e ("outro teste") e (teste ADJ simples)','retorno':True},
            {'texto':'outro \n teste <br> simples','criterio':'(outro adjc2 simples) OU (outro adjc teste) OU (teste adjc2 simples)','retorno':False},
            {'texto':'outro \n teste <br> simples','criterio':'(outro adj2 simples) e (teste adj simples)','retorno':True},
            {'texto':'outro \n teste <br> simples','criterio':'teste E (teste adjc1 simples)','retorno':False},
            {'texto':'outro \n teste <br> simples','criterio':'(NÃO casa) (Não nada) (não "tudo") (nao "não")','retorno':True},
            {'texto':'outro \n teste <br> simples','criterio':'(outro não "Não") (outro (não "Não"))','retorno':True},
            {'texto':'outro \n teste <br> simples','criterio':'teste NÃO (teste adjc1 simples)','retorno':True},
            ]

TESTES_USADOS_PROD = [
            {'texto': 'cópia da petição de fls. 200-200215 ao Juízo 200-200 de primeira', 'criterio': "'cópia' adjc15 Juízo adjc10 primeira", 'retorno': True},
            {'texto': 'cópia da petição de fls. 200-200215 <br><br>ao Juízo 200-200 de primeira', 'criterio': "'cópia' adjc15 Juízo adjc10 primeira", 'retorno': False},
            {'texto': 'cópia da petição de fls. 200-200215 ao Juízo 200-200 de primeira', 'criterio': "'cópia' proxc15 Juízo adjc10 primeira", 'retorno': True}, 
            {'texto': 'teste de texto agravo não provido ou sei lá', 'criterio': 'teste adj4 agravo', 'retorno': True}, 
            {'texto': 'a casa<br><br>grande', 'criterio': 'grande proxc10 casa', 'retorno': False}, 
            {'texto': 'nesse contexto, indefiro a liminar entre outras coisas mais, solicito e quero muito mais quaisquer informações', 'criterio': 'indefir$ adj4 liminar (solicit$ adj5 informações)', 'retorno': False}, 
            {'texto': 'confirmando que o dano moral que pode ser estético foi presumida a', 'criterio': "'dano moral' adj5 estético não (presumido? ou presumida?)", 'retorno': False}, 
            {'texto': 'Solicitem-se, ao Juízo da 1ª Vara Criminal de Suzano-SP, informações', 'criterio': "('Solicito' ou 'solicite' ou 'solicite$' ou 'solicitem$' ou 'Solicitando' ou 'Requisit$' ou 'Necessário') adj15  'informações'", 'retorno': True}, 
            {'texto': 'teste de texto agravo não provido ou sei lá', 'criterio': 'r:(agravo\\\\s+a)', 'retorno': False}, 
            {'texto': 'teste de texto agravo foi provido ou <br>sei lá', 'criterio': "agravo adj5 provido nao ('nao provido')", 'retorno': True}, 
            {'texto': 'a casa<br><br>grande', 'criterio': 'casa adjc10 grande', 'retorno': False}, 
            {'texto': 'conforme encaminho esses autos para turma julgadora do juizo de retratacao', 'criterio': '(encaminh$ ou remet$ ou remessa) adj2 (autos ou processo ou feito) adj2 Turma adj2 julgadora adj4 juízo adj2 retratação', 'retorno': True}, 
            {'texto': 'a casa de papel e um filme interessante', 'criterio': '(casa ou apartamento) adj3 papel ou folha', 'retorno': True}, 
            {'texto': 'a casa de bla-bla-bla papel', 'criterio': 'casa ADJ3 papel', 'retorno': False}, 
            {'texto': 'as casas de papel um video interessante', 'criterio': '(casa? ou apartamento?) adj3 (papel ou folha ou papeis) adj3 (filme ou video) adj2 interessante', 'retorno': True}, 
            {'texto': 'recurso quase especial dá-se um grande provimento no agravo em recurso especial', 'criterio': "(RESP ou 'recurso especial') ou (Dá-se ou dou) adj4 provimento adj3 'agravo em recurso especial'", 'retorno': True}, 
            {'texto': 'a turma resolveu conceder um habeas corpus por meio desse oficio legal', 'criterio': "(conceder adj2 'habeas corpus' adj4 'ofício')", 'retorno': True}, 
            {'texto': 'a casa de papel <br><br>o papel dele é interessante na série', 'criterio': 'casa COM papel COM serie', 'retorno': False}, 
            {'texto': 'a casa de papel é uma série muito interessante', 'criterio': 'casa COM papel COM serie COM interessante', 'retorno': True}, 
            {'texto': 'sendo assim, ou não, determino imediata remessa do processo feito neste órgão sempre julgador  do juízo de retratação', 'criterio': 'Determino adj4 (encaminhamento ou remessa) adj4 (autos ou processo ou feito) adj4 (órgão ou turma) adj2 julgador$ adj4 juízo adj2 retratação', 'retorno': True}, 
            {'texto': 'casas de da do papel', 'criterio': '(casas ou apartamento) adj3 (papel ou folha ou papeis)', 'retorno': False}, 
            {'texto': 'a redução do estômago foi bem sucedida', 'criterio': '(bariatrica ou obesidade ou gastroplastia) ou (redu$ adj2 estoma$)', 'retorno': True}, 
            {'texto': 'a turma resolveu conceder um habeas corpus por meio desse oficio legal', 'criterio': "conceder adj2 'habeas corpus' adj4 'ofício'", 'retorno': True}, 
            {'texto': 'sendo assim, ou não, determino imediato encaminhamento dos autos deste<br>processo ao órgão sempre julgador  do juízo de retratação', 'criterio': 'Determino adj4 (encaminhamento ou remessa) adj4 (autos ou processo ou feito) adj4 (órgão ou turma) adj2 julgador$ adj4 juízo adj2 retratação', 'retorno': True}, 
            {'texto': 'confirmando que o dano moral que pode ser estético foi assumido a', 'criterio': "'dano moral' adj5 estético não (presumido? ou presumida?)", 'retorno': True}, 
            {'texto': 'dano  bla material', 'criterio': '(dano ou moral) adj2 (dano ou material)', 'retorno': True}, 
            {'texto': 'o apartamento de folha e um filme interessante', 'criterio': '(casa ou apartamento) adj3 papel ou folha adj3 filme', 'retorno': True}, 
            {'texto': 'teste de texto agravo não provido ou sei lá', 'criterio': "agravo adj5 provido nao ('nao provido')", 'retorno': False}, 
            {'texto': 'a casa de ferro é um teste', 'criterio': 'casa ADJ1 de ADJ1 ferro e teste', 'retorno': True}, 
            {'texto': "'sendo assim, ou não, determino imediata remessa do processo feito nesta fantástica turma sempre julgadora para o juízo de retratação'", 'criterio': 'Determino adj4 (encaminhamento ou remessa) adj4 (autos ou processo ou feito) adj4 (órgão ou turma) adj2 julgador$ adj4 juízo adj2 retratação', 'retorno': True}, 
            {'texto': 'nesse contexto, indefiro a liminar entre outras coisas mais, solicito muito mais informações', 'criterio': 'indefir$ adj4 liminar (solicit$ adj5 informações)', 'retorno': True}, 
            {'texto': 'ele fez uma bariatrica esse mês', 'criterio': '(bariatrica ou obesidade ou gastroplastia) ou (redu$ adj2 estoma$)', 'retorno': True}, 
            {'texto': 'a b c d e f', 'criterio': '(a adj b adj c) ou (c adj d)', 'retorno': True}, 
            {'texto': 'cópia da petição de fls. 200-200215<br><br> ao Juízo 200-200 de <br><br> primeira', 'criterio': "'cópia' proxc15 Juízo adj10 primeira", 'retorno': False}, 
            {'texto': 'cópia da petição de fls. 200-200215<br><br> ao Juízo 200-200 de <br><br> primeira', 'criterio': "'cópia' prox15 Juízo adj10 primeira", 'retorno': True}
]

TESTES_COMPLETOS = TESTES_BASICOS + TESTES_USADOS_PROD + [
                {"texto":"falha do teste (texto simples para usar de teste de quebra quando necessário - colocar false como esperado e o teste quebra)", "criterio":"falha adj1 do adj1 teste", "retorno": True },
                {'texto':'esse essa teste simples', 'criterio':'esse NÃO essa', 'retorno':False},
                {'texto':'esse essa teste simples', 'criterio':'(esse OU essa) teste simples', 'retorno':True },
                {'texto':'esse essa teste simples', 'criterio':'esse ADJ2 teste ADJ1 simples', 'retorno':True },
                {'texto': 'áéíóúàâôçÁÉÍÓÚÀÂÔÇ Üü texto123', 'criterio':'texto 123 uu aeiouaaocaeiouaaoc', 'retorno': True},
                {'texto': __texto__, 'criterio': "casa adj2 papel", 'retorno' : True},
                {'texto': __texto__, 'criterio': "'numero 123' prox3 interessante", 'retorno' : True},
                {'texto': __texto__, 'criterio': "casa adj6 seriado", 'retorno' : True},
                {'texto': __texto__, 'criterio': "seriado prox3 papel", 'retorno' : True},
                {'texto': __texto__, 'criterio': "casa adj3 seriado", 'retorno' : False},
                {'texto': __texto__, 'criterio': "(casa prox4 seriado) ou (seriado adj1 interessante)", 'retorno' : False},
                {'texto': __texto__, 'criterio': "(casa prox4 seriado) ou (seriado adj1 interessante) ou uns", 'retorno' : True},
                {'texto': __texto__, 'criterio': "pape$ ou seria$", 'retorno' : True},
                {'texto': {'a':__texto__,'b': 'segundo'}, 'criterio': "(casa papel) e segund$", 'retorno' : True},
                {'texto': 'esses textos \ntem\n os e literais para uns testes sorridente', 'criterio': "texto com literal", 'retorno' : False},
                {'texto': 'esses textos \ntem\n os e literais para uns testes sorridente', 'criterio': "texto com2 literal", 'retorno' : False},
                {'texto': 'esses textos \ntem\n os e literais para uns testes sorridente', 'criterio': "texto com3 literal", 'retorno' : True},
                {'texto': {'a':__texto__,'b': 'segundo'}, 'criterio': "(casa papel) com segund$", 'retorno' : False},
                {'texto': {'a':__texto__,'b': 'segundo'}, 'criterio': "(casa papel) e segund$.b.", 'retorno' : True},
                {'texto': {'a':__texto__,'b': 'segundo'}, 'criterio': "(casa papel).a. e segund$.b. e 'casa de papel'.a. (seriado segundo) ", 'retorno' : True},
                {'texto': {'a':__texto__,'b': 'segundo texto com o número 1234'}, 'criterio': "(casa papel) e segund$.b. e 1234.b>=. e 123.b>. e 12345.b<=. ", 'retorno' : True},
                {'texto': {'a':__texto__,'b': 'segundo texto com o número 1234'}, 'criterio': "(casa papel) e segund$.b. e 1234.b>=. e @b>'123' e @b<=12345 ", 'retorno' : True},
                {'texto': {'a':__texto__,'b': '12 123 1 13 1234'}, 'criterio': " (1235.b>. ou 1236.b>.) ou @b>'12345' ", 'retorno' : False},
                {'texto': {'a':__texto__,'b': 'a aa b '}, 'criterio': " (ddd.b>. ou bbbb.b>.) ou @b>'ccc' ", 'retorno' : False},
                {'texto': "o instituto nacional de seguridade social fez um teste com texto literal", 'criterio' : 'texto com literais (teste OU testa) ("inss" ou "CaSa de pApél")', 'retorno': True},
                {"texto":"	teste de texto agravo não provido ou sei lá	", "criterio":"	teste adj4 agravo	", "retorno":	True	},
                {"texto":"	a casa<br>grande	", "criterio":"	grande proxc10 casa	", "retorno":	False	},
                {"texto":"	nesse contexto, indefiro a liminar entre outras coisas mais, solicito e quero muito mais quaisquer informações	", "criterio":"	indefir$ adj4 liminar (solicit$ adj5 informações)	", "retorno":	False	},
                {"texto":"	confirmando que o dano moral que pode ser estético foi presumida a	", "criterio":"	'dano moral' adj5 estético não (presumido? ou presumida?)	", "retorno":	False	},
                {"texto":"	conforme encaminho esses autos para turma julgadora do juizo de retratacao	", "criterio":"	(encaminh$ ou remet$ ou remessa) adj2 (autos ou processo ou feito) adj2 Turma adj2 julgadora adj4 juízo adj2 retratação	", "retorno":True	},
                {"texto":"	a casa de papel e um filme interessante	", "criterio":"	(casa ou apartamento) adj3 papel ou folha	", "retorno":	True	},
                {"texto":"	teste de texto agravo foi provido ou sei lá	", "criterio":"	agravo adj5 provido nao ('nao provido')	", "retorno":	True	},
                {"texto":"	a casa<br>grande	", "criterio":"	casa adjc10 grande	", "retorno":	0	},
                {"texto":"	as casas de papel um video interessante	", "criterio":"	(casa? ou apartamento?) adj3 papel ou folha ou papeis adj3 filme ou video adj2 interessante	", "retorno":	True	},
                {"texto":"	recurso quase especial dá-se um grande provimento no agravo em recurso especial	", "criterio":"	(RESP ou 'recurso especial') ou (Dá-se ou dou) adj4 provimento adj3 'agravo em recurso especial'	", "retorno":	True	},
                {"texto":"	a turma resolveu conceder um habeas corpus por meio desse oficio legal	", "criterio":"	(conceder adj2 'habeas corpus' adj4 'ofício')	", "retorno":	True	},
                {"texto":"	a casa de papel <br>o papel dele é interessante na série	", "criterio":"	casa COM papel COM serie	", "retorno":	False	},
                {"texto":"	a casa de papel é uma série muito interessante	", "criterio":"	casa COM papel COM serie COM interessante	", "retorno":	True	},
                {"texto":"	sendo assim, ou não, determino imediata remessa do processo feito neste órgão sempre julgador  do juízo de retratação	", "criterio":"	Determino adj4 (encaminhamento ou remessa) adj4 (autos ou processo ou feito) adj4 (órgão ou turma) adj2 julgador$ adj4 juízo adj2 retratação	", "retorno":	True	},
                {"texto":"	casas de da do papel	", "criterio":"	(casas ou apartamento) adj3 (papel ou folha ou papeis)	", "retorno":	False	},
                {"texto":"	a redução do estômago foi bem sucedida	", "criterio":"	(bariatrica ou obesidade ou gastroplastia) ou (redu$ adj2 estoma$)	", "retorno":	True	},
                {"texto":"	a turma resolveu conceder um habeas corpus por meio desse oficio legal	", "criterio":"	conceder adj2 'habeas corpus' adj4 'ofício'	", "retorno":	True	},
                {"texto":"	sendo assim, ou não, determino imediato encaminhamento dos autos deste processo ao órgão sempre julgador  do juízo de retratação	", "criterio":"	Determino adj4 (encaminhamento ou remessa) adj4 (autos ou processo ou feito) adj4 (órgão ou turma) adj2 julgador$ adj4 juízo adj2 retratação	", "retorno":	True	},
                {"texto":"	confirmando que o dano moral que pode ser estético foi assumido a	", "criterio":"	'dano moral' adj5 estético não (presumido? ou presumida?)	", "retorno":	True	},
                {"texto":"	teste de texto agravo não provido ou sei lá	", "criterio":"	agravo adj5 provido nao ('nao provido')	", "retorno":	False	},
                {"texto":"	a casa de ferro é um teste	", "criterio":"	casa ADJ1 de ADJ1 ferro e teste	", "retorno":	True	},
                {"texto":"	'sendo assim, ou não, determino imediata remessa do processo feito nesta fantástica turma sempre julgadora para o juízo de retratação'	", "criterio":"	Determino adj4 (encaminhamento ou remessa) adj4 (autos ou processo ou feito) adj4 (órgão ou turma) adj2 julgador$ adj4 juízo adj2 retratação	", "retorno":	True	},
                {"texto":"	nesse contexto, indefiro a liminar entre outras coisas mais, solicito muito mais informações	", "criterio":"	indefir$ adj4 liminar (solicit$ adj5 informações)	", "retorno":	True	},
                {"texto":"	ele fez uma bariatrica esse mês	", "criterio":"	(bariatrica ou obesidade ou gastroplastia) ou (redu$ adj2 estoma$)	", "retorno":	True	},
                {"texto":"	a b c d e f	", "criterio":"	(a adj b adj c) ou (c adj d)	", "retorno":	True	},
                {"texto":"	dano  bla material	", "criterio":"	(dano ou moral) adj2 (dano ou material)	", "retorno":	True	},
                {"texto":"	o apartamento de folha e um filme interessante	", "criterio":"	(casa ou apartamento) adj3 (papel ou folha) adj3 filme	", "retorno":	True	},
                {"texto": {"a":"esse é um teste com campos", "b":"esse outro teste com campos"}, "criterio": "(teste adj2 campos) e (outro com teste)" , "retorno":	True	},
                {"texto": {"a":"esse é o primeiro texto ", "b":"esse é o segundo texto"}, "criterio": "(primeiro com segundo)" , "retorno":	False	},
                {"texto": {"a":"esse é o primeiro texto ", "b":"esse é o segundo texto"}, "criterio": "(primeir? e segun$ e tex*)" , "retorno":	True	},
                {"texto": "153.972.567. números quebrados por pontos", "criterio": "1539725$ E ('1539725'$ ou '1.539. 725'$ ou '1283540' ou '1.283.540'$)", "retorno": True},
                {"texto": " conteúdo no meio com critérios com todos os curingas", "criterio": "$ri$ri$ E ?ur?nga? ", "retorno": 1, "retorno_aon": False},
                {'texto': "palavra contendo teste", "criterio": "palavraa NAO (palavrab E palavrac com palavra e palavra nao (palavra ou palavra)) E palavraf nao teste", "retorno": False},
                {'texto': "palavraa contendo testa", "criterio": "palavraa NAO (palavrab E palavrac com palavra e palavra nao (palavra ou palavra)) E palavraf nao teste", "retorno": True}
                ]

TESTES_TEXTOS = [
            {'texto':'esse é um simples teste de tokenização',
             'mapa': {'esse': {'t': [0], 'p': [0], 'c': ['']}, 'e': {'t': [1], 'p': [0], 'c': ['']}, 'um': {'t': [2], 'p': [0], 'c': ['']}, 'simples': {'t': [3], 'p': [0], 'c': ['']}, 'teste': {'t': [4], 'p': [0], 'c': ['']}, 'de': {'t': [5], 'p': [0], 'c': ['']}, 'tokenizacao': {'t': [6], 'p': [0], 'c': ['']}} 
             },
            {'texto':'fazer-se-ia um texto top-blaster, mas não deu',
             'mapa': {'fazer': {'t': [0], 'p': [0], 'c': ['']}, 'se': {'t': [1], 'p': [0], 'c': ['']}, 'ia': {'t': [2], 'p': [0], 'c': ['']}, 'um': {'t': [3], 'p': [0], 'c': ['']}, 'texto': {'t': [4], 'p': [0], 'c': ['']}, 'top': {'t': [5], 'p': [0], 'c': ['']}, 'blaster': {'t': [6], 'p': [0], 'c': ['']}, 'ma': {'t': [7], 'p': [0], 'c': ['']}, 'nao': {'t': [8], 'p': [0], 'c': ['']}, 'deu': {'t': [9], 'p': [0], 'c': ['']} } 
             },
            {'texto':'Senhor, conceda-me a serenidade para aceitar aquilo que não posso mudar, a coragem para mudar o que me for possível e a sabedoria para saber discernir entre as duas.<br>Pois assim poderei ser razoavelmente feliz nesta vida e supremamente feliz na outra.', 
             'mapa':{'senhor': {'t': [0], 'p': [0], 'c': ['']}, 'conceda': {'t': [1], 'p': [0], 'c': ['']}, 'me': {'t': [2, 18], 'p': [0, 0], 'c': ['', '']}, 'a': {'t': [3, 12, 22, 28], 'p': [0, 0, 0, 0], 'c': ['', '', '', '']}, 'serenidade': {'t': [4], 'p': [0], 'c': ['']}, 'para': {'t': [5, 14, 24], 'p': [0, 0, 0], 'c': ['', '', '']}, 'aceitar': {'t': [6], 'p': [0], 'c': ['']}, 'aquilo': {'t': [7], 'p': [0], 'c': ['']}, 'que': {'t': [8, 17], 'p': [0, 0], 'c': ['', '']}, 'nao': {'t': [9], 'p': [0], 'c': ['']}, 'posso': {'t': [10], 'p': [0], 'c': ['']}, 
             'mudar': {'t': [11, 15], 'p': [0, 0], 'c': ['', '']}, 'coragem': {'t': [13], 'p': [0], 'c': ['']}, 'o': {'t': [16], 'p': [0], 'c': ['']}, 'for': {'t': [19], 'p': [0], 'c': ['']}, 'possivel': {'t': [20], 'p': [0], 'c': ['']}, 'e': {'t': [21, 38], 'p': [0, 1], 'c': ['', '']}, 'sabedoria': {'t': [23], 'p': [0], 'c': ['']}, 'saber': {'t': [25], 'p': [0], 'c': ['']}, 'discernir': {'t': [26], 'p': [0], 'c': ['']}, 'entre': {'t': [27], 'p': [0], 'c': ['']}, 'dua': {'t': [29], 'p': [0], 'c': ['']}, 'pol': {'t': [30], 'p': [1], 'c': ['']}, 'assim': {'t': [31], 'p': [1], 'c': ['']}, 
             'poderei': {'t': [32], 'p': [1], 'c': ['']}, 'ser': {'t': [33], 'p': [1], 'c': ['']}, 'razoavelmente': {'t': [34], 'p': [1], 'c': ['']}, 'feliz': {'t': [35, 40], 'p': [1, 1], 'c': ['', '']}, 'nesta': {'t': [36], 'p': [1], 'c': ['']}, 'vida': {'t': [37], 'p': [1], 'c': ['']}, 'supremamente': {'t': [39], 'p': [1], 'c': ['']}, 'na': {'t': [41], 'p': [1], 'c': ['']}, 'outra': {'t': [42], 'p': [1], 'c': ['']}}
             },
             {'texto': 'esse é um texto<br>com mais de uma linha\ntestando vários tipos de quebras\rfinal',
              'mapa' : {'esse': {'t': [0], 'p': [0], 'c': ['']}, 'e': {'t': [1], 'p': [0], 'c': ['']}, 'um': {'t': [2], 'p': [0], 'c': ['']}, 'texto': {'t': [3], 'p': [0], 'c': ['']}, 'com': {'t': [4], 'p': [1], 'c': ['']}, 'mal': {'t': [5], 'p': [1], 'c': ['']}, 'de': {'t': [6, 12], 'p': [1, 2], 'c': ['', '']}, 
              'uma': {'t': [7], 'p': [1], 'c': ['']}, 'linha': {'t': [8], 'p': [1], 'c': ['']}, 'testando': {'t': [9], 'p': [2], 'c': ['']}, 'vario': {'t': [10], 'p': [2], 'c': ['']}, 'tipo': {'t': [11], 'p': [2], 'c': ['']}, 'quebra': {'t': [13], 'p': [2], 'c': ['']}, 'final': {'t': [14], 'p': [2], 'c': ['']}}
              }
    ]

TESTES_CRITERIOS  = [
            {'criterio': "palavra E palavra COM palavra OU palavra NAO (palavra)",
             'criterio_tokens': ['palavra', 'e', 'palavra', 'com', 'palavra', 'ou', 'palavra', 'nao', '(', 'palavra', ')'],
             'criterio_aon': '( palavra AND palavra AND palavra ) OR palavra NOT ( palavra )',
             },
            {'criterio': '(NÃO casa) (Não nada) (não "tudo") (nao "não")',
             'criterio_tokens': ['(', 'nao', 'casa', ')', '(', 'nao', 'nada', ')', '(', 'nao', '(', '"', 'tudo', '"', ')', '(', 'nao', '"', 'nao', '"', ')', ')'],
             'criterio_aon': '( NOT casa ) AND ( NOT nada ) AND ( NOT ( "tudo" ) AND ( NOT "nao" ) )',
             },
            {'criterio': "palavraa NAO (palavrab E palavrac)",
             'criterio_tokens': ['palavraa', 'nao', '(', 'palavrab', 'e', 'palavrac',')'],
             'criterio_aon': 'palavraa NOT ( palavrab AND palavrac )',
             },
            {'criterio': "palavraa NAO (palavrab ADJ1 palavrac)",
             'criterio_tokens': ['palavraa', 'nao', '(', 'palavrab', 'adj1', 'palavrac',')'],
             'criterio_aon': 'palavraa',
             },
            {'criterio': "palavraa NAO (palavrab E palavrac com palavra e palavra nao (palavra ou palavra)) E palavraf nao teste",
             'criterio_tokens': ['palavraa', 'nao', '(', 'palavrab', 'e', 'palavrac', 'com', 'palavra', 'e', 'palavra', 'nao', '(', 'palavra', 'ou', 'palavra', ')', ')', 'e', 'palavraf', 'nao', 'teste'],
             'criterio_aon': 'palavraa NOT teste',
             },
    ]


if __name__ == '__main__':
    unittest.main(buffer=True)