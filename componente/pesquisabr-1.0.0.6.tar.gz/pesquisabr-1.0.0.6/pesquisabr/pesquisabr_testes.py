import unittest
import re 
import sys

from pesquisabr import PesquisaBR, RegrasPesquisaBR


class TestPesquisaBR(unittest.TestCase):

    def teste(self):
        self.assertTrue(len(TESTES_COMPLETOS)>0)
        self.assertTrue(len(__texto__)>0)

    ###########################################################
    ## básicos - tokens, critérios, etc
    def teste_criterios_tokens(self):
        _criterios = 'esse teste simples'
        _texto = 'esse é um teste simples repetindo teste simples'
        pb = PesquisaBR(texto=_texto, criterios=_criterios, print_debug=False)
        if not pb.retorno():
            self.print_erro('TEXTO EM DICIONÁRIO - esperado False')
            pb.print_resumo()
        self.assertEqual(pb.retorno(), True)
        # verifica os tokens
        tokens_esperados = ['esse','e','um','teste','simples','repetindo','teste','simples']
        self.assertCountEqual(pb.tokens_texto, tokens_esperados)
        # verifica os tokens únicos
        tokens_esperados = ['esse','e','um','teste','simples','repetindo']
        self.assertCountEqual(pb.tokens_texto_unicos, tokens_esperados)
        # verifica crit[erios]
        self.assertEqual(pb.criterios, 'esse E teste E simples')
        # verifica AON
        self.assertEqual(pb.criterios_and_or_not, 'esse AND teste AND simples')
        # verifica o mapa
        mapa_texto = {'e': {'c': [''], 'p': [0], 't': [1]},
                      'esse': {'c': [''], 'p': [0], 't': [0]},
                      'repetindo': {'c': [''], 'p': [0], 't': [5]},
                      'simples': {'c': ['', ''], 'p': [0, 0], 't': [4, 7]},
                      'teste': {'c': ['', ''], 'p': [0, 0], 't': [3, 6]},
                      'um': {'c': [''], 'p': [0], 't': [2]}}
        self.assertDictEqual(pb.mapa_texto, mapa_texto)
        # singulares
        _texto = 'casas tres simples abbtas thrs ghdls wcasas ycasas as es is os us '
        _texto += ' ' + ' '.join(PesquisaBR.LST_SINGULAR_IGNORAR)
        pb = PesquisaBR(texto=_texto, criterios='', print_debug=False)
        tokens_esperados = ['casa','simples','tres','abbtas','ghdls','thrs','wcasas','ycasas','a','e','il','o','u']
        tokens_esperados += PesquisaBR.LST_SINGULAR_IGNORAR
        self.assertCountEqual(pb.tokens_texto_unicos, list(set(tokens_esperados)))

    ###########################################################
    ## criérios básicos
    def teste_criterios_basicos(self):
        self.testes_completos(testes=TESTES_BASICOS,somar_internos=False)
        #self.assertTrue(False)


    ###########################################################
    ## básicos - tokens, critérios, etc
    def teste_sinonimos(self):
        _criterios = 'ele adj3 alegre'
        _texto = 'ele está muito feliz'
        pb = PesquisaBR(texto=_texto, criterios=_criterios, print_debug=False)
        if not pb.retorno():
            self.print_erro('SINÔNIMOS - esperado True')
            pb.print_resumo()
        self.assertEqual(pb.retorno(), True)

        # desativa o dicionário e testa novamente
        pb = PesquisaBR(texto='', criterios=_criterios, print_debug=False)
        pb.SINONIMOS = {}
        pb.novo_texto(_texto,atualizar_pesquisa=True)
        if pb.retorno():
            self.print_erro('SINÔNIMOS - esperado False')
            pb.print_resumo()
        self.assertEqual(pb.retorno(), False)

        pb = PesquisaBR(texto=_texto, criterios=_criterios, print_debug=False)
        # verifica o mapa
        mapa_texto = {'ele': {'t': [0], 'p': [0], 'c': ['']}, 
                      'esta': {'t': [1], 'p': [0], 'c': ['']}, 
                      'muito': {'t': [2], 'p': [0], 'c': ['']}, 
                      'feliz': {'t': [3], 'p': [0], 'c': ['']}}
        print(pb.mapa_texto)              
        self.assertDictEqual(pb.mapa_texto, mapa_texto)

    def teste_texto_dicionario_1(self):
        _criterios = 'texto com civil não aqui'
        _texto = {'texto':'texto aqui responsabilidade civil do estado','numero':123}
        pb = PesquisaBR(texto=_texto, criterios=_criterios, print_debug=False)
        if pb.retorno():
            self.print_erro('TEXTO EM DICIONÁRIO - esperado False')
            pb.print_resumo()
        self.assertEqual(pb.retorno(), False)

    def teste_texto_dicionario_2(self):
        _criterios = '((purgação adj2 mora) com ((integr$ ou tota$) com dívida ou débito ou pagamento) ou débito) e ((busca adj2 apreensao) ou 911/??69)'
        _texto = {'texto':'texto aleatório para passar - purgação de mora por ocorrer na integração de uma dívida no débito para ocorrer busca e apreensao','numero':123}
        pb = PesquisaBR(texto=_texto, criterios=_criterios, print_debug=False)
        if not pb.retorno():
            self.print_erro('TEXTO EM DICIONÁRIO - esperado True')
            pb.print_resumo()
        self.assertEqual(pb.retorno(), True)

    ################################################################################
    # realiza testes internos e pode receber testes complementares
    # se um teste falhar, ativa o debug e realiza novamente o teste
    # para apresentar facilitar a análise - interrompe os testes ao falhar um deles
    ################################################################################
    def testes_completos(self,testes=None, somar_internos=True):
        # {"texto" : "", "criterio":, "resposta" : true/false}

        # remover o próximo comentário para testar falha do teste
        # TESTES_COMPLETOS[0]['retorno'] =False

        """
        Teste com as principais regras e combinações conhecidas
        """
        falha = ''
        pb=PesquisaBR()
        _testes = []
        if (testes is None) or (somar_internos):
            _testes = TESTES_COMPLETOS
        fim_internos = len(_testes) if not (_testes is None) else -1
        if not (testes is None):
            _testes += testes
        pb.print_debug = False
        for i, teste in enumerate(_testes):
            if i == fim_internos :
                print('---------------------------------------')
                print('------  FIM DOS TESTES INTERNOS -------')
            texto = teste['texto']
            criterio = teste['criterio']
            print('---------------------------------------')
            print(f'Teste: {i} - {criterio}  ==> esperado {teste["retorno"]}')
            pb.novo_texto(texto)
            pb.novo_criterio(criterio)
            if teste["retorno"]:
                print(f'   AON => {pb.criterios_and_or_not}')
            retorno = None
            if pb.erros =='':
                retorno = pb.analisar_mapa_pesquisa()
            if pb.erros!= '' or retorno != teste['retorno']:
                if pb.erros != '':
                    falha = f'ERRO NOS CRITÉRIOS: {pb.erros}'
                    self.print_erro(falha)
                else:
                    falha = f'ERRO NO RETORNO ESPERADO: {retorno} != {teste["retorno"]}'
                    self.print_erro(falha)
                pb.print_debug = True
                pb.print()
                pb.analisar_mapa_pesquisa()
                break
            # verifica a reconstrução da pesquisa apenas pelo mapa 
            # o resultado tem que ser o mesmo ao criar o mapa em tempo de execução
            pbmapa = PesquisaBR(criterios=pb.criterios, mapa_texto = pb.mapa_texto)            
            retorno = pbmapa.analisar_mapa_pesquisa() if pbmapa.erros == '' else None
            if pbmapa.erros!= '' or retorno != teste['retorno']:
                falha = 'ERRO AO REFAZAR A PESQUISA PELO MAPA'
                self.print_erro(falha)
                print(f' - Teste: {i} - {criterio}  ==> esperado {teste["retorno"]}')
                if pbmapa.erros != '':
                    print(' -- ERRO NOS CRITÉRIOS: ', pbmapa.erros)
                pbmapa.print_debug = True
                pbmapa.print()
                pbmapa.analisar_mapa_pesquisa()
                break
            # verifica o clone dos critérios
            # o resultado tem que ser o mesmo
            pbclone = pb.clone_criterios()
            pbclone.novo_mapa_texto(mapa_texto=pb.mapa_texto)
            retorno = pbclone.retorno() if pbclone.erros == '' else None
            if pbclone.erros!= '' or retorno != teste['retorno']:
                falha = 'ERRO AO REFAZER A PESQUISA PELO CLONE'
                self.print_erro(falha)
                print(f' - Teste: {i} - {criterio}  ==> esperado {teste["retorno"]}')
                if pbclone.erros != '':
                    print(' -- ERRO NOS CRITÉRIOS DO CLONE: ', pbmapa.erros)
                pbclone.print_debug = True
                pbclone.print()
                pbclone.analisar_mapa_pesquisa()
                break

            # verifica o AND OR NOT
            # convertendo a pesquisa em AND OR NOT, caso a pesquisa toda retorne TRUE, o 
            # critério AND OR NOT tem que retornar TRUE também
            # AND OR NOT é usado para acelerar a pesquisa em bancos textuais como o MemSQL/SingleStore
            criterio_aon = re.sub(' AND ',' E ', str(pb.criterios_and_or_not))
            criterio_aon = re.sub(' OR ',' OU ', criterio_aon)
            criterio_aon = re.sub(' NOT ',' NAO ', criterio_aon)
            _retorno_aon = teste.get('retorno_aon',teste["retorno"])
            if criterio_aon.strip() !='':
                if _retorno_aon==1 or _retorno_aon == True:
                    pb.novo_criterio(criterio_aon)
                    if pb.erros =='':
                        retorno = pb.analisar_mapa_pesquisa()
                    if pb.erros != '' or not retorno:
                        falha = 'CRITÉRIO AND OR NOT - FALHA ESPERADO TRUE ***'
                        print(falha)
                        if pb.erros != '':
                            print('ERRO NOS CRITÉRIOS: ', pb.erros)
                        pb.print_debug = True
                        pb.print()
                        pb.analisar_mapa_pesquisa()
                        break
            else:
                print(f'   AON => VAZIO *** ')

        self.print_erro(falha)
        self.assertEqual(len(falha)==0, True)

    ###########################################################
    ## REGRAS
    REGRAS_TESTES = [{'grupo' : 'receitas_bolo', 'rotulo': 'Receita de Bolo', 'regra': 'receita ADJ10 bolo'},
                {'grupo' : 'receitas_bolo', 'rotulo': 'Receita de Bolo', 'regra': 'aprenda ADJ5 fazer ADJ10 bolo'},
                {'grupo' : 'receitas_pao', 'rotulo': 'Receita de Pão', 'regra': 'receita PROX15 pao'},
                {'grupo' : 'grupo teste', 'rotulo': 'teste', 'regra': 'teste'}]
    def teste_regras_1(self):
        regras = self.REGRAS_TESTES
        # receita de bolo
        texto = 'nessa receita você vai aprender a fazer bolos incríveis'
        pbr = RegrasPesquisaBR(regras = regras, print_debug=False)
        rotulos = pbr.aplicar_regras(texto = texto)
        print(f'Rótulos encontrados para o texto: "{texto}" >> ', rotulos)
        self.assertCountEqual(rotulos['rotulos'], ['Receita de Bolo'])
        # receita de pão
        texto = 'pão de ló, uma receita incrível'
        pbr = RegrasPesquisaBR(regras = regras, print_debug=False)
        rotulos = pbr.aplicar_regras(texto = texto)
        print(f'Rótulos encontrados para o texto: "{texto}" >> ', rotulos)
        self.assertCountEqual(rotulos['rotulos'], ['Receita de Pão'])
        # receita de pão e bolo
        texto = 'pão de ló, uma receita incrível para uma nova forma de fazer um bolo'
        pbr = RegrasPesquisaBR(regras = regras, print_debug=False)
        rotulos = pbr.aplicar_regras(texto = texto)
        print(f'Rótulos encontrados para o texto: "{texto}" >> ', rotulos)
        self.assertCountEqual(rotulos['rotulos'], ['Receita de Pão', 'Receita de Bolo'])

    def teste_regras_2(self):
        falha = ''
        __teste_regras__ = [{'grupo' : 'grupo 1', 'rotulo': 'ok1', 'regra': 'casa ADJ2 papel'},
                            {'grupo' : 'grupo 1', 'rotulo': 'ok1', 'regra': 'seriado ADJ2 "la casa de papel"'},
                            {'grupo' : 'grupo 2', 'rotulo': 'ok2', 'regra': '"a casa de papel"'},
                            {'grupo' : 'grupo teste', 'rotulo': 'teste', 'regra': 'teste'}
                            ]
        __teste_regras_2__ = [{'grupo' : 'grupo cabecalho', 'rotulo': 'cabecalho', 'regra': 'texto', 'qtd_cabecalho':10},
                                {'grupo' : 'grupo rodape', 'rotulo': 'rodape', 'regra': 'rodapé', 'qtd_rodape':10},
                                {'grupo' : 'grupo cab rodap', 'rotulo': 'cabrodap', 'regra': 'texto E teste','qtd_cabecalho':10, 'qtd_rodape':23},
                                {'grupo' : 'grupo n cab rodap', 'rotulo': 'ncabrodap', 'regra': 'NÃO cabecalho','qtd_cabecalho':20, 'qtd_rodape':20}
                            ]
        __texto_teste__ = 'o seriado a casa de papel é legal'
        __texto_teste_2__ = 'texto com teste depois do cabecalho e teste antes do rodapé'
        #
        _obj_teste = RegrasPesquisaBR(regras = __teste_regras__, print_debug=False)
        resdic = _obj_teste.aplicar_regras(__texto_teste__)
        self.assertCountEqual(resdic['rotulos'], ['ok1','ok2'])
        # incluindo teste na pesquisa
        resdic = _obj_teste.aplicar_regras(__texto_teste__ + ' com esse teste')
        self.assertCountEqual(resdic['rotulos'], ['ok1','ok2','teste'])
        # texto sem regras aplicáveis
        resdic = _obj_teste.aplicar_regras('esse é um texto qualquer com a casa mas não tem nada de papel')
        self.assertCountEqual(resdic['rotulos'], [])
        # testes de cabeçalho e rodapé 
        _obj_teste = RegrasPesquisaBR(regras = __teste_regras_2__, print_debug=False)
        resdic = _obj_teste.aplicar_regras(__texto_teste_2__)
        self.assertCountEqual(resdic['rotulos'], ['cabrodap','cabecalho','ncabrodap','rodape'])

    def print_erro(self, msg_erro):
        if not msg_erro:
            return
        print( '###########################################################################')
        print( '########## ')
        print(f'########## {msg_erro}')
        print( '########## ')
        print( '###########################################################################')


__texto__ = "a casa de papel é um seriado bem interessante numero123"
TESTES_BASICOS = [
            {'texto':'essa teste simples','criterio':'(esse OU essa OU nada) ADJC teste PROXC simples','retorno':True},
            {'texto':'esse essa \n teste \r simples','criterio':'(esse OU essa) teste simples','retorno':True},
            {'texto':'essa \n teste \r simples','criterio':'(esse OU essa) ADJ teste ADJ simples','retorno':True},
            {'texto':'outro \n teste \r simples','criterio':'(esse OU esso OU outro OU outra OU essa) ADJ teste ADJ simples','retorno':True},
            {'texto':'outro \n teste \r simples','criterio':'(esse OU esso OU outro OU outra OU essa) ADJC teste ADJ simples','retorno':False},
]

TESTES_COMPLETOS = TESTES_BASICOS + [
                {"texto":"falha do teste (texto simples para usar de teste de quebra quando necessário - colocar false como esperado e o teste quebra)", "criterio":"falha adj1 do adj1 teste", "retorno": True },
                {'texto':'esse essa teste simples', 'criterio':'esse NÃO essa', 'retorno':False},
                {'texto':'esse essa teste simples', 'criterio':'(esse OU essa) teste simples', 'retorno':True },
                {'texto':'esse essa teste simples', 'criterio':'esse ADJ2 teste ADJ1 simples', 'retorno':True },
                {'texto': 'áéíóúàâôçÁÉÍÓÚÀÂÔÇ Üü texto123', 'criterio':'texto 123 uu aeiouaaocaeiouaaoc', 'retorno': True},
                {'texto': __texto__, 'criterio': "casa adj2 papel", 'retorno' : True},
                {'texto': __texto__, 'criterio': "'numero 123' prox3 interessante", 'retorno' : True},
                {'texto': __texto__, 'criterio': "casa adj6 seriado", 'retorno' : True},
                {'texto': __texto__, 'criterio': "seriado prox3 papel", 'retorno' : True},
                {'texto': __texto__, 'criterio': "casa adj3 seriado", 'retorno' : False},
                {'texto': __texto__, 'criterio': "(casa prox4 seriado) ou (seriado adj1 interessante)", 'retorno' : False},
                {'texto': __texto__, 'criterio': "(casa prox4 seriado) ou (seriado adj1 interessante) ou uns", 'retorno' : True},
                {'texto': __texto__, 'criterio': "pape$ ou seria$", 'retorno' : True},
                {'texto': {'a':__texto__,'b': 'segundo'}, 'criterio': "(casa papel) e segund$", 'retorno' : True},
                {'texto': 'esses textos \ntem\n os e literais para uns testes sorridente', 'criterio': "texto com literal", 'retorno' : False},
                {'texto': 'esses textos \ntem\n os e literais para uns testes sorridente', 'criterio': "texto com2 literal", 'retorno' : False},
                {'texto': 'esses textos \ntem\n os e literais para uns testes sorridente', 'criterio': "texto com3 literal", 'retorno' : True},
                {'texto': {'a':__texto__,'b': 'segundo'}, 'criterio': "(casa papel) com segund$", 'retorno' : False},
                {'texto': {'a':__texto__,'b': 'segundo'}, 'criterio': "(casa papel) e segund$.b.", 'retorno' : True},
                {'texto': {'a':__texto__,'b': 'segundo'}, 'criterio': "(casa papel).a. e segund$.b. e 'casa de papel'.a. (seriado segundo) ", 'retorno' : True},
                {'texto': {'a':__texto__,'b': 'segundo texto com o número 1234'}, 'criterio': "(casa papel) e segund$.b. e 1234.b>=. e 123.b>. e 12345.b<=. ", 'retorno' : True},
                {'texto': {'a':__texto__,'b': 'segundo texto com o número 1234'}, 'criterio': "(casa papel) e segund$.b. e 1234.b>=. e @b>'123' e @b<=12345 ", 'retorno' : True},
                {'texto': {'a':__texto__,'b': '12 123 1 13 1234'}, 'criterio': " (1235.b>. ou 1236.b>.) ou @b>'12345' ", 'retorno' : False},
                {'texto': {'a':__texto__,'b': 'a aa b '}, 'criterio': " (ddd.b>. ou bbbb.b>.) ou @b>'ccc' ", 'retorno' : False},
                {'texto': "o instituto nacional de seguridade social fez um teste com texto literal", 'criterio' : 'texto com literais (teste OU testa) ("inss" ou "CaSa de pApél")', 'retorno': True},
                {"texto":"	teste de texto agravo não provido ou sei lá	", "criterio":"	teste adj4 agravo	", "retorno":	1	},
                {"texto":"	a casa<br>grande	", "criterio":"	grande proxc10 casa	", "retorno":	0	},
                {"texto":"	nesse contexto, indefiro a liminar entre outras coisas mais, solicito e quero muito mais quaisquer informações	", "criterio":"	indefir$ adj4 liminar (solicit$ adj5 informações)	", "retorno":	0	},
                {"texto":"	confirmando que o dano moral que pode ser estético foi presumida a	", "criterio":"	'dano moral' adj5 estético não (presumido? ou presumida?)	", "retorno":	0	},
                {"texto":"	conforme encaminho esses autos para turma julgadora do juizo de retratacao	", "criterio":"	(encaminh$ ou remet$ ou remessa) adj2 (autos ou processo ou feito) adj2 Turma adj2 julgadora adj4 juízo adj2 retratação	", "retorno":	1	},
                {"texto":"	a casa de papel e um filme interessante	", "criterio":"	(casa ou apartamento) adj3 papel ou folha	", "retorno":	1	},
                {"texto":"	teste de texto agravo foi provido ou sei lá	", "criterio":"	agravo adj5 provido nao ('nao provido')	", "retorno":	1	},
                {"texto":"	a casa<br>grande	", "criterio":"	casa adjc10 grande	", "retorno":	0	},
                {"texto":"	as casas de papel um video interessante	", "criterio":"	(casa? ou apartamento?) adj3 papel ou folha ou papeis adj3 filme ou video adj2 interessante	", "retorno":	1	},
                {"texto":"	recurso quase especial dá-se um grande provimento no agravo em recurso especial	", "criterio":"	(RESP ou 'recurso especial') ou (Dá-se ou dou) adj4 provimento adj3 'agravo em recurso especial'	", "retorno":	1	},
                {"texto":"	a turma resolveu conceder um habeas corpus por meio desse oficio legal	", "criterio":"	(conceder adj2 'habeas corpus' adj4 'ofício')	", "retorno":	1	},
                {"texto":"	a casa de papel <br>o papel dele é interessante na série	", "criterio":"	casa COM papel COM serie	", "retorno":	0	},
                {"texto":"	a casa de papel é uma série muito interessante	", "criterio":"	casa COM papel COM serie COM interessante	", "retorno":	1	},
                {"texto":"	sendo assim, ou não, determino imediata remessa do processo feito neste órgão sempre julgador  do juízo de retratação	", "criterio":"	Determino adj4 (encaminhamento ou remessa) adj4 (autos ou processo ou feito) adj4 (órgão ou turma) adj2 julgador$ adj4 juízo adj2 retratação	", "retorno":	1	},
                {"texto":"	casas de da do papel	", "criterio":"	(casas ou apartamento) adj3 (papel ou folha ou papeis)	", "retorno":	0	},
                {"texto":"	a redução do estômago foi bem sucedida	", "criterio":"	(bariatrica ou obesidade ou gastroplastia) ou (redu$ adj2 estoma$)	", "retorno":	1	},
                {"texto":"	a turma resolveu conceder um habeas corpus por meio desse oficio legal	", "criterio":"	conceder adj2 'habeas corpus' adj4 'ofício'	", "retorno":	1	},
                {"texto":"	sendo assim, ou não, determino imediato encaminhamento dos autos deste processo ao órgão sempre julgador  do juízo de retratação	", "criterio":"	Determino adj4 (encaminhamento ou remessa) adj4 (autos ou processo ou feito) adj4 (órgão ou turma) adj2 julgador$ adj4 juízo adj2 retratação	", "retorno":	1	},
                {"texto":"	confirmando que o dano moral que pode ser estético foi assumido a	", "criterio":"	'dano moral' adj5 estético não (presumido? ou presumida?)	", "retorno":	1	},
                {"texto":"	teste de texto agravo não provido ou sei lá	", "criterio":"	agravo adj5 provido nao ('nao provido')	", "retorno":	0	},
                {"texto":"	a casa de ferro é um teste	", "criterio":"	casa ADJ1 de ADJ1 ferro e teste	", "retorno":	1	},
                {"texto":"	'sendo assim, ou não, determino imediata remessa do processo feito nesta fantástica turma sempre julgadora para o juízo de retratação'	", "criterio":"	Determino adj4 (encaminhamento ou remessa) adj4 (autos ou processo ou feito) adj4 (órgão ou turma) adj2 julgador$ adj4 juízo adj2 retratação	", "retorno":	1	},
                {"texto":"	nesse contexto, indefiro a liminar entre outras coisas mais, solicito muito mais informações	", "criterio":"	indefir$ adj4 liminar (solicit$ adj5 informações)	", "retorno":	1	},
                {"texto":"	ele fez uma bariatrica esse mês	", "criterio":"	(bariatrica ou obesidade ou gastroplastia) ou (redu$ adj2 estoma$)	", "retorno":	1	},
                {"texto":"	a b c d e f	", "criterio":"	(a adj b adj c) ou (c adj d)	", "retorno":	1	},
                {"texto":"	dano  bla material	", "criterio":"	(dano ou moral) adj2 (dano ou material)	", "retorno":	1	},
                {"texto":"	o apartamento de folha e um filme interessante	", "criterio":"	(casa ou apartamento) adj3 (papel ou folha) adj3 filme	", "retorno":	1	},
                {"texto": {"a":"esse é um teste com campos", "b":"esse outro teste com campos"}, "criterio": "(teste adj2 campos) e (outro com teste)" , "retorno":	1	},
                {"texto": {"a":"esse é o primeiro texto ", "b":"esse é o segundo texto"}, "criterio": "(primeiro com segundo)" , "retorno":	0	},
                {"texto": {"a":"esse é o primeiro texto ", "b":"esse é o segundo texto"}, "criterio": "(primeir? e segun$ e tex*)" , "retorno":	1	},
                {"texto": "153.972.567. números quebrados por pontos", "criterio": "1539725$ E ('1539725'$ ou '1.539. 725'$ ou '1283540' ou '1.283.540'$)", "retorno": 1},
                {"texto": " conteúdo no meio com critérios com todos os curingas", "criterio": "$ri$ri$ E ?ur?nga? ", "retorno": 1, "retorno_aon": 0}]


if __name__ == '__main__':
    unittest.main(buffer=True)