# Colocar um import em cada linha
name = "pesquisabr"
#import pesquisabr.pesquisabr as pesquisabr
#import pesquisabr.pesquisabr_testes as pesquisabr_testes
from pesquisabr.pesquisabr import PesquisaBR
from pesquisabr.pesquisabr import RegrasPesquisaBR
from pesquisabr.pesquisabr_testes import PesquisaBRTestes
from pesquisabr.util import Util
#import pesquisabr.util_memsql
#import pesquisabr.pesquisabr_memsql
 