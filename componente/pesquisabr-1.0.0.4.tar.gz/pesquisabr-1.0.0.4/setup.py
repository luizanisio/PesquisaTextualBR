import setuptools
#
# Para gerar o dist, executar: 
#   python setup.py sdist 

setuptools.setup(
    name="pesquisabr",
    version= '1.0.0.4',
    author="Luiz Anísio",
    author_email="",
    description="Projeto para pesquisa textual",
    long_description='Pacote base para os projetos com pesquisa textual avançada',
    long_description_content_type="text/markdown",
    url="https://github.com/luizanisio/PesquisaTextualBR",
    packages = setuptools.find_packages(),
    package_data={'':['*.md','LICENCE'],},
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: MIT License",
        "Operating System :: OS Independent",
    ],
)

