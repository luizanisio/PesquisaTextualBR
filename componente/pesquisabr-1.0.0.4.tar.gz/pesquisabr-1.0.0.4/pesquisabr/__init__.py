#name = "pesquisabr"
#import pesquisabr
#import pesquisabr.pesquisabr_memsql
#import pesquisabr.util
#import pesquisabr.util_memsql
